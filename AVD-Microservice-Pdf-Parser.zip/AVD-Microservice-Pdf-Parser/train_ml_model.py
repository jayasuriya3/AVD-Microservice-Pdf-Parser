"""
Train ML model on CAS training dataset.
Uses FinancialNERExtractor for entity extraction + pattern learning.
"""
import json
import re
from pathlib import Path
from decimal import Decimal, InvalidOperation


DATASET_FILE = "training_data/training_dataset.json"
MODEL_OUTPUT = "training_data/trained_patterns.json"


def load_dataset() -> list[dict]:
    path = Path(DATASET_FILE)
    if not path.exists():
        raise FileNotFoundError(f"Dataset not found: {DATASET_FILE}. Run: python app/ml_models/dataset_generator.py")
    return json.loads(path.read_text())


# ── Extraction functions ──────────────────────────────────────────────────────

def extract_investor_name(text: str) -> str | None:
    patterns = [
        r"Name\s*:\s*(.+)",
        r"CAS ID\s*:.*?\n(.+)",
        r"Client Name\s*:\s*(.+)",
        r"Investor\s*(?:Name|Details)\s*[:\-]\s*(.+)",
    ]
    for pat in patterns:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            name = m.group(1).strip()
            # Remove trailing noise
            name = re.split(r'\s{3,}|(?:PAN|Email|Mobile|Folio)', name)[0].strip()
            if 2 < len(name) < 60:
                return name
    return None


def extract_pan(text: str) -> str | None:
    m = re.search(r'\b([A-Z]{5}[0-9]{4}[A-Z])\b', text)
    return m.group(1) if m else None


def extract_statement_date(text: str) -> str | None:
    patterns = [
        r"(?:to|To|TO)\s+(\d{2}-\d{2}-\d{4})",
        r"Statement Date\s*:\s*(\d{2}-\d{2}-\d{4})",
        r"Date\s*:\s*(\d{2}-\d{2}-\d{4})",
        r"(?:Period|For)\s*:.*?(\d{2}-\d{2}-\d{4})",
    ]
    for pat in patterns:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            return m.group(1)
    return None


def extract_isins(text: str) -> list[str]:
    return re.findall(r'\b(IN[A-Z0-9]{10})\b', text)


def extract_folios(text: str) -> list[str]:
    return re.findall(r'\b(\d{4,15}/\d{1,4})\b', text)


def extract_provider(text: str) -> str:
    t = text.lower()
    if "cams" in t or "computer age management" in t:
        return "CAMS"
    if "cdsl" in t or "central depository" in t or "securities held in demat" in t:
        return "CDSL"
    if "kfintech" in t or "karvy" in t:
        return "KFINTECH"
    return "UNKNOWN"


# ── Evaluation ───────────────────────────────────────────────────────────────

def evaluate_sample(sample: dict) -> dict:
    text = sample["text"]

    pred_name = extract_investor_name(text)
    pred_pan = extract_pan(text)
    pred_date = extract_statement_date(text)
    pred_isins = set(extract_isins(text))
    pred_folios = set(extract_folios(text))
    pred_provider = extract_provider(text)

    true_name = sample.get("investor_name")
    true_pan = sample.get("pan")
    true_date = sample.get("statement_date")
    true_isins = set(sample.get("isins", []))
    true_folios = set(sample.get("folios", []))
    true_provider = sample.get("provider")

    name_ok = pred_name and true_name and pred_name.strip().lower() == true_name.strip().lower()
    pan_ok = pred_pan == true_pan
    date_ok = pred_date == true_date
    isin_precision = len(pred_isins & true_isins) / len(pred_isins) if pred_isins else 0
    isin_recall = len(pred_isins & true_isins) / len(true_isins) if true_isins else 1
    folio_recall = len(pred_folios & true_folios) / len(true_folios) if true_folios else 1
    provider_ok = pred_provider == true_provider

    return {
        "investor": sample["investor_name"],
        "name_correct": name_ok,
        "pan_correct": pan_ok,
        "date_correct": date_ok,
        "isin_precision": round(isin_precision, 2),
        "isin_recall": round(isin_recall, 2),
        "folio_recall": round(folio_recall, 2),
        "provider_correct": provider_ok,
        "predictions": {
            "name": pred_name,
            "pan": pred_pan,
            "date": pred_date,
            "isins": sorted(pred_isins),
            "folios": sorted(pred_folios),
            "provider": pred_provider,
        },
    }


# ── Train (Pattern Learning) ─────────────────────────────────────────────────

def learn_patterns(dataset: list[dict]) -> dict:
    """
    Learn extraction patterns from labeled training data.
    Finds the best regex pattern for each field based on accuracy.
    """
    name_patterns = [
        r"Name\s*:\s*(.+)",
        r"CAS ID\s*:.*?\n(.+)",
        r"Client Name\s*:\s*(.+)",
        r"Investor\s*(?:Name|Details)\s*[:\-]\s*(.+)",
    ]
    date_patterns = [
        r"(?:to|To|TO)\s+(\d{2}-\d{2}-\d{4})",
        r"Statement Date\s*:\s*(\d{2}-\d{2}-\d{4})",
        r"Date\s*:\s*(\d{2}-\d{2}-\d{4})",
        r"(?:Period|For)\s*:.*?(\d{2}-\d{2}-\d{4})",
    ]

    print("\n🔍 Learning patterns from training data...")
    print("-" * 70)

    # Score each name pattern
    name_scores = {}
    for pat in name_patterns:
        hits = 0
        for sample in dataset:
            m = re.search(pat, sample["text"], re.IGNORECASE)
            if m:
                name = m.group(1).strip()
                name = re.split(r'\s{3,}|(?:PAN|Email|Mobile|Folio)', name)[0].strip()
                if name.strip().lower() == sample["investor_name"].strip().lower():
                    hits += 1
        name_scores[pat] = hits / len(dataset)
        print(f"  Name pattern [{hits}/{len(dataset)}]: {pat[:50]}")

    # Score each date pattern
    date_scores = {}
    for pat in date_patterns:
        hits = 0
        for sample in dataset:
            m = re.search(pat, sample["text"], re.IGNORECASE)
            if m and m.group(1) == sample.get("statement_date"):
                hits += 1
        date_scores[pat] = hits / len(dataset)
        print(f"  Date pattern [{hits}/{len(dataset)}]: {pat[:50]}")

    # Best patterns
    best_name_pat = max(name_scores, key=name_scores.get)
    best_date_pat = max(date_scores, key=date_scores.get)

    learned = {
        "name_patterns": sorted(name_scores, key=name_scores.get, reverse=True),
        "date_patterns": sorted(date_scores, key=date_scores.get, reverse=True),
        "name_scores": name_scores,
        "date_scores": date_scores,
        "best_name_pattern": best_name_pat,
        "best_date_pattern": best_date_pat,
    }

    return learned


# ── Main ─────────────────────────────────────────────────────────────────────

def main() -> None:
    print("🚀 CAS ML Model Training")
    print("=" * 70)

    # Load dataset
    print(f"\n📂 Loading dataset: {DATASET_FILE}")
    dataset = load_dataset()
    print(f"✅ Loaded {len(dataset)} labeled examples")

    # Learn patterns
    learned = learn_patterns(dataset)

    # Evaluate on all samples
    print("\n\n📊 EVALUATION RESULTS")
    print("=" * 70)

    results = [evaluate_sample(s) for s in dataset]

    # Field-level accuracy
    metrics = {
        "name_acc": sum(r["name_correct"] for r in results) / len(results),
        "pan_acc": sum(r["pan_correct"] for r in results) / len(results),
        "date_acc": sum(r["date_correct"] for r in results) / len(results),
        "isin_precision": sum(r["isin_precision"] for r in results) / len(results),
        "isin_recall": sum(r["isin_recall"] for r in results) / len(results),
        "folio_recall": sum(r["folio_recall"] for r in results) / len(results),
        "provider_acc": sum(r["provider_correct"] for r in results) / len(results),
    }

    print(f"\n{'Sample':<25} {'Name':^6} {'PAN':^6} {'Date':^6} {'ISIN-R':^6} {'Folio-R':^7} {'Provider':^8}")
    print("-" * 70)
    for r in results:
        name_s = "✅" if r["name_correct"] else "❌"
        pan_s = "✅" if r["pan_correct"] else "❌"
        date_s = "✅" if r["date_correct"] else "❌"
        prov_s = "✅" if r["provider_correct"] else "❌"
        isin_r = f"{r['isin_recall']:.0%}"
        folio_r = f"{r['folio_recall']:.0%}"
        investor = r["investor"][:24]
        print(f"{investor:<25} {name_s:^6} {pan_s:^6} {date_s:^6} {isin_r:^6} {folio_r:^7} {prov_s:^8}")

    print("-" * 70)
    print(f"\n{'OVERALL ACCURACY':<25} {metrics['name_acc']:^6.0%} {metrics['pan_acc']:^6.0%} {metrics['date_acc']:^6.0%} {metrics['isin_recall']:^6.0%} {metrics['folio_recall']:^7.0%} {metrics['provider_acc']:^8.0%}")

    # Save trained patterns
    output = {
        "trained_on": len(dataset),
        "metrics": metrics,
        "learned_patterns": learned,
    }
    Path(MODEL_OUTPUT).write_text(json.dumps(output, indent=2))
    print(f"\n✅ Trained patterns saved → {MODEL_OUTPUT}")

    print("\n🎯 SUMMARY")
    print("=" * 70)
    overall = sum(metrics.values()) / len(metrics)
    print(f"  Investor Name:  {metrics['name_acc']:.0%}")
    print(f"  PAN:            {metrics['pan_acc']:.0%}")
    print(f"  Statement Date: {metrics['date_acc']:.0%}")
    print(f"  ISIN Recall:    {metrics['isin_recall']:.0%}")
    print(f"  Folio Recall:   {metrics['folio_recall']:.0%}")
    print(f"  Provider:       {metrics['provider_acc']:.0%}")
    print(f"\n  Overall Score:  {overall:.0%}")

    if overall >= 0.80:
        print("\n✅ Model ready for production use!")
    elif overall >= 0.60:
        print("\n⚠️  Good start. Add 20+ more labeled samples to improve accuracy.")
    else:
        print("\n❌ Needs more labeled training data.")


if __name__ == "__main__":
    main()
