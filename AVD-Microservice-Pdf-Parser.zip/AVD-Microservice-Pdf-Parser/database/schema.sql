-- ============================================================
-- CAS Parser Database Schema
-- Supports: CDSL, NSDL, CAMS, KFintech
-- API inputs: firm_id (caller org), client_id (investor id at firm)
-- ============================================================

-- ── Reference tables ─────────────────────────────────────────

CREATE TABLE firms (
    firm_id       UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    firm_name     TEXT        NOT NULL,
    firm_code     TEXT        UNIQUE NOT NULL,          -- e.g. "WEALTH_MGR_01"
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE clients (
    client_id     UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    firm_id       UUID        NOT NULL REFERENCES firms(firm_id),
    external_ref  TEXT        NOT NULL,                 -- firm's own client ID
    full_name     TEXT,
    pan           TEXT,                                 -- unmasked if available
    email         TEXT,
    mobile        TEXT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (firm_id, external_ref)
);

-- ── Core statement table ──────────────────────────────────────

CREATE TABLE cas_statements (
    statement_id      UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    firm_id           UUID        NOT NULL REFERENCES firms(firm_id),
    client_id         UUID        NOT NULL REFERENCES clients(client_id),
    parse_id          UUID        NOT NULL UNIQUE,      -- from API response
    provider          TEXT        NOT NULL CHECK (provider IN ('CDSL','NSDL','CAMS','KFINTECH','UNKNOWN')),
    depository        TEXT        CHECK (depository IN ('CDSL','NSDL')),
    statement_date    DATE,
    generated_date    DATE,
    -- Investor snapshot at parse time
    investor_name     TEXT,
    investor_pan      TEXT,                             -- may be masked
    investor_email    TEXT,
    investor_mobile   TEXT,
    -- Parse metadata
    parse_status      TEXT        NOT NULL DEFAULT 'COMPLETED',
    parse_confidence  NUMERIC(4,3),
    provider_signals  TEXT[],
    source_filename   TEXT,
    parsed_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    raw_warnings      TEXT[]
);

CREATE INDEX ON cas_statements (firm_id);
CREATE INDEX ON cas_statements (client_id);
CREATE INDEX ON cas_statements (statement_date);
CREATE INDEX ON cas_statements (provider);

-- ── Demat accounts (CDSL + NSDL) ─────────────────────────────

CREATE TABLE demat_accounts (
    account_id    UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    statement_id  UUID        NOT NULL REFERENCES cas_statements(statement_id) ON DELETE CASCADE,
    depository    TEXT        NOT NULL CHECK (depository IN ('CDSL','NSDL')),
    dp_name       TEXT,
    dp_id         TEXT,
    demat_client_id TEXT,                               -- DP's own client ID
    account_value NUMERIC(18,2),                        -- total value of holdings
    as_of_date    DATE
);

CREATE INDEX ON demat_accounts (statement_id);
CREATE INDEX ON demat_accounts (dp_id, demat_client_id);

-- ── Demat holdings ────────────────────────────────────────────

CREATE TABLE demat_holdings (
    holding_id    UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id    UUID        NOT NULL REFERENCES demat_accounts(account_id) ON DELETE CASCADE,
    statement_id  UUID        NOT NULL REFERENCES cas_statements(statement_id) ON DELETE CASCADE,
    isin          TEXT        NOT NULL,
    security_name TEXT,
    trading_symbol TEXT,
    asset_class   TEXT        CHECK (asset_class IN ('EQUITY','DEBT','MF_UNITS','PREFERENCE','OTHER')),
    quantity      NUMERIC(18,6)  NOT NULL,
    market_price  NUMERIC(18,4),
    current_value NUMERIC(18,2)
);

CREATE INDEX ON demat_holdings (account_id);
CREATE INDEX ON demat_holdings (statement_id);
CREATE INDEX ON demat_holdings (isin);

-- ── Demat transactions ────────────────────────────────────────

CREATE TABLE demat_transactions (
    txn_id        UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id    UUID        NOT NULL REFERENCES demat_accounts(account_id) ON DELETE CASCADE,
    statement_id  UUID        NOT NULL REFERENCES cas_statements(statement_id) ON DELETE CASCADE,
    isin          TEXT,
    txn_date      DATE        NOT NULL,
    description   TEXT,
    credit_units  NUMERIC(18,6),
    debit_units   NUMERIC(18,6),
    closing_balance NUMERIC(18,6)
);

CREATE INDEX ON demat_transactions (account_id);
CREATE INDEX ON demat_transactions (txn_date);
CREATE INDEX ON demat_transactions (isin);

-- ── Mutual fund folios (CDSL / CAMS / KFintech) ───────────────

CREATE TABLE mf_folios (
    folio_id      UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    statement_id  UUID        NOT NULL REFERENCES cas_statements(statement_id) ON DELETE CASCADE,
    folio_number  TEXT        NOT NULL,
    amc_name      TEXT,
    kyc_status    TEXT,
    nominee       TEXT
);

CREATE INDEX ON mf_folios (statement_id);
CREATE INDEX ON mf_folios (folio_number);

-- ── MF schemes per folio ──────────────────────────────────────

CREATE TABLE mf_schemes (
    scheme_id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    folio_id          UUID        NOT NULL REFERENCES mf_folios(folio_id) ON DELETE CASCADE,
    statement_id      UUID        NOT NULL REFERENCES cas_statements(statement_id) ON DELETE CASCADE,
    isin              TEXT,
    scheme_name_raw   TEXT,
    scheme_name       TEXT,                             -- normalized name
    face_value        NUMERIC(10,2),
    units             NUMERIC(18,6),
    nav               NUMERIC(14,6),
    current_value     NUMERIC(18,2),
    invested_value    NUMERIC(18,2),
    gain_loss         NUMERIC(18,2),
    -- Computed
    gain_loss_pct     NUMERIC(8,4)
        GENERATED ALWAYS AS (
            CASE WHEN invested_value > 0
                 THEN ((current_value - invested_value) / invested_value) * 100
            END
        ) STORED,
    extraction_confidence NUMERIC(4,3)
);

CREATE INDEX ON mf_schemes (folio_id);
CREATE INDEX ON mf_schemes (statement_id);
CREATE INDEX ON mf_schemes (isin);

-- ── MF transactions per scheme ────────────────────────────────

CREATE TABLE mf_transactions (
    txn_id        UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    scheme_id     UUID        NOT NULL REFERENCES mf_schemes(scheme_id) ON DELETE CASCADE,
    statement_id  UUID        NOT NULL REFERENCES cas_statements(statement_id) ON DELETE CASCADE,
    txn_date      DATE        NOT NULL,
    txn_type      TEXT        CHECK (txn_type IN ('SIP','PURCHASE','REDEMPTION','SWITCH_IN','SWITCH_OUT','DIVIDEND','BONUS')),
    amount        NUMERIC(18,2),
    units         NUMERIC(18,6),
    nav           NUMERIC(14,6)
);

CREATE INDEX ON mf_transactions (scheme_id);
CREATE INDEX ON mf_transactions (txn_date);

-- ── Portfolio snapshot view ───────────────────────────────────
-- Aggregated view for quick portfolio summary per client

CREATE VIEW client_portfolio_summary AS
SELECT
    c.client_id,
    c.firm_id,
    c.external_ref,
    c.full_name,
    cs.statement_id,
    cs.provider,
    cs.statement_date,
    cs.investor_pan,
    -- MF total
    COALESCE(SUM(DISTINCT ms.current_value), 0)         AS mf_current_value,
    COALESCE(SUM(DISTINCT ms.invested_value), 0)        AS mf_invested_value,
    -- Demat total
    COALESCE(SUM(DISTINCT dh.current_value), 0)         AS demat_current_value,
    -- Counts
    COUNT(DISTINCT mf.folio_id)                         AS folio_count,
    COUNT(DISTINCT ms.scheme_id)                        AS scheme_count,
    COUNT(DISTINCT dh.holding_id)                       AS holding_count
FROM clients c
JOIN cas_statements cs        ON cs.client_id = c.client_id
LEFT JOIN mf_folios mf        ON mf.statement_id = cs.statement_id
LEFT JOIN mf_schemes ms       ON ms.folio_id = mf.folio_id
LEFT JOIN demat_accounts da   ON da.statement_id = cs.statement_id
LEFT JOIN demat_holdings dh   ON dh.account_id = da.account_id
GROUP BY c.client_id, c.firm_id, c.external_ref, c.full_name,
         cs.statement_id, cs.provider, cs.statement_date, cs.investor_pan;
