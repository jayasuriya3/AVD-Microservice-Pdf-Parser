"""
Debug extracted PDF text and classifier scores.
Usage: python debug_pdf.py <path_to_pdf>
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from app.extractors.pdfplumber_extractor import PdfPlumberExtractor
from app.extractors.pymupdf_extractor import PyMuPDFExtractor
from app.extractors.pymupdf_extractor import PyMuPDFExtractor
from app.models.document import ExtractedDocument
from app.classifier.cdsl_rules import CDSLRules
from app.classifier.cams_rules import CAMSRules
from app.classifier.kfintech_rules import KFintechRules


def debug_pdf(pdf_path: str, password: str | None = None) -> None:
    path = Path(pdf_path)
    if not path.exists():
        print(f"[ERROR] File not found: {pdf_path}")
        return

    print(f"\n[PDF] Extracting: {path.name}")
    print("=" * 70)

    extractor = PdfPlumberExtractor()
    fallback = PyMuPDFExtractor()

    # Try provided password, then common CAS passwords, then no password
    passwords_to_try = []
    if password:
        passwords_to_try.append(password)
    passwords_to_try += [None]  # no password last

    doc = None
    for pwd in passwords_to_try:
        try:
            doc = extractor.extract(path, password=pwd)
            if pwd:
                print(f"[INFO] Opened with password: {pwd}")
            break
        except Exception:
            try:
                doc = fallback.extract(path, password=pwd)
                if pwd:
                    print(f"[INFO] Opened via PyMuPDF with password: {pwd}")
                break
            except Exception:
                continue

    if doc is None:
        print("[ERROR] Could not open PDF. Try: python debug_pdf.py <file.pdf> <password>")
        print("        Common passwords: PAN number, date of birth (DDMMYYYY), email")
        return

    text = doc.text

    print(f"Pages: {len(doc.pages)}")
    print(f"Total chars extracted: {len(text)}")

    # Print first 3000 chars of raw text
    print("\n--- RAW TEXT (first 3000 chars) ---")
    print(repr(text[:3000]))

    # Print each page separately (first 3 pages)
    print("\n--- PAGE-BY-PAGE ---")
    for i, page in enumerate(doc.pages[:4], 1):
        print(f"\n[Page {i}] ({len(page.raw_text)} chars)")
        print(page.raw_text[:800])
        print("...")

    # Classifier scores
    print("\n--- CLASSIFIER SCORES ---")
    cdsl_score = CDSLRules().score(doc)
    cams_score = CAMSRules().score(doc)
    kft_score = KFintechRules().score(doc)
    print(f"CDSL:     {cdsl_score.confidence} — signals: {cdsl_score.signals}")
    print(f"CAMS:     {cams_score.confidence} — signals: {cams_score.signals}")
    print(f"KFintech: {kft_score.confidence}  — signals: {kft_score.signals}")

    winner = max([cdsl_score, cams_score, kft_score], key=lambda x: x.confidence)
    print(f"Winner: {winner.name} ({winner.confidence})")

    # Check CDSL-specific markers in text
    print("\n--- CDSL KEYWORD CHECK ---")
    tns = text.lower().replace(" ", "")
    tl = text.lower()
    checks = {
        '"cas id:"': "cas id:" in tl,
        '"casid" (no spaces)': "casid" in tns,
        '"securities held in demat"': "securities held in demat" in tl,
        '"demat account"': "demat account" in tl,
        '"cdsl"': "cdsl" in tl,
        '"central depository"': "central depository" in tl,
        '"centraldepository" (no spaces)': "centraldepository" in tns,
        '"cams"': "cams" in tl,
        '"consolidated account statement"': "consolidated account statement" in tl,
        '"dp name"': "dp name" in tl,
        '"dp id"': "dp id" in tl,
    }
    for label, found in checks.items():
        status = "YES" if found else "NO "
        print(f"  {status} {label}")

    # Show lines around "ISIN" keyword to understand scheme format
    print("\n--- LINES AROUND ISIN (first 5) ---")
    lines = text.splitlines()
    isin_count = 0
    for i, line in enumerate(lines):
        if "ISIN" in line.upper() and isin_count < 5:
            start = max(0, i - 3)
            end = min(len(lines), i + 4)
            print(f"\n  [Lines {start+1}-{end}]")
            for j in range(start, end):
                marker = " >> " if j == i else "    "
                print(f"  {marker}{repr(lines[j])}")
            isin_count += 1

    # Show lines containing numbers (for valuation pattern debug)
    print("\n--- LINES WITH DECIMAL NUMBERS (first 10) ---")
    import re
    count = 0
    for line in lines:
        if re.search(r'\d+\.\d{3}', line) and count < 10:
            print(f"  {repr(line)}")
            count += 1


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python debug_pdf.py <path_to_pdf> [password]")
        sys.exit(1)
    pdf_password = sys.argv[2] if len(sys.argv) >= 3 else None
    debug_pdf(sys.argv[1], pdf_password)
