import uuid
from datetime import date
from decimal import Decimal

from sqlalchemy import (
    Date, ForeignKey, Numeric, String, Text, ARRAY,
    UniqueConstraint, func,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.connection import Base


class Firm(Base):
    __tablename__ = "firms"

    firm_id:    Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    firm_name:  Mapped[str]       = mapped_column(Text, nullable=False)
    firm_code:  Mapped[str]       = mapped_column(Text, unique=True, nullable=False)
    created_at: Mapped[date]      = mapped_column(server_default=func.now())

    clients:    Mapped[list["Client"]] = relationship(back_populates="firm")


class Client(Base):
    __tablename__ = "clients"
    __table_args__ = (UniqueConstraint("firm_id", "external_ref"),)

    client_id:    Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    firm_id:      Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("firms.firm_id"), nullable=False)
    external_ref: Mapped[str]       = mapped_column(Text, nullable=False)
    full_name:    Mapped[str | None] = mapped_column(Text)
    pan:          Mapped[str | None] = mapped_column(String(10))
    email:        Mapped[str | None] = mapped_column(Text)
    mobile:       Mapped[str | None] = mapped_column(Text)
    created_at:   Mapped[date]       = mapped_column(server_default=func.now())

    firm:       Mapped["Firm"]             = relationship(back_populates="clients")
    statements: Mapped[list["CasStatement"]] = relationship(back_populates="client")


class CasStatement(Base):
    __tablename__ = "cas_statements"

    statement_id:     Mapped[uuid.UUID]   = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    firm_id:          Mapped[uuid.UUID]   = mapped_column(UUID(as_uuid=True), ForeignKey("firms.firm_id"), nullable=False)
    client_id:        Mapped[uuid.UUID]   = mapped_column(UUID(as_uuid=True), ForeignKey("clients.client_id"), nullable=False)
    parse_id:         Mapped[uuid.UUID]   = mapped_column(UUID(as_uuid=True), unique=True, nullable=False)
    provider:         Mapped[str]         = mapped_column(String(20), nullable=False)
    depository:       Mapped[str | None]  = mapped_column(String(10))
    statement_date:   Mapped[date | None] = mapped_column(Date)
    generated_date:   Mapped[date | None] = mapped_column(Date)
    investor_name:    Mapped[str | None]  = mapped_column(Text)
    investor_pan:     Mapped[str | None]  = mapped_column(String(12))
    investor_email:   Mapped[str | None]  = mapped_column(Text)
    investor_mobile:  Mapped[str | None]  = mapped_column(Text)
    parse_status:     Mapped[str]         = mapped_column(String(20), server_default="COMPLETED")
    parse_confidence: Mapped[Decimal | None] = mapped_column(Numeric(4, 3))
    provider_signals: Mapped[list[str] | None] = mapped_column(ARRAY(Text))
    source_filename:  Mapped[str | None]  = mapped_column(Text)
    firm_code:        Mapped[str | None]  = mapped_column(Text)   # the string the caller passed
    client_ref:       Mapped[str | None]  = mapped_column(Text)   # the string the caller passed
    raw_warnings:     Mapped[list[str] | None] = mapped_column(ARRAY(Text))
    parsed_at:        Mapped[date]        = mapped_column(server_default=func.now())

    client:          Mapped["Client"]            = relationship(back_populates="statements")
    demat_accounts:  Mapped[list["DematAccount"]] = relationship(back_populates="statement", cascade="all, delete-orphan")
    mf_folios:       Mapped[list["MfFolio"]]      = relationship(back_populates="statement", cascade="all, delete-orphan")


class DematAccount(Base):
    __tablename__ = "demat_accounts"

    account_id:       Mapped[uuid.UUID]   = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    statement_id:     Mapped[uuid.UUID]   = mapped_column(UUID(as_uuid=True), ForeignKey("cas_statements.statement_id", ondelete="CASCADE"), nullable=False)
    depository:       Mapped[str]         = mapped_column(String(10), nullable=False)
    dp_name:          Mapped[str | None]  = mapped_column(Text)
    dp_id:            Mapped[str | None]  = mapped_column(String(20))
    demat_client_id:  Mapped[str | None]  = mapped_column(String(20))
    account_value:    Mapped[Decimal | None] = mapped_column(Numeric(18, 2))
    as_of_date:       Mapped[date | None] = mapped_column(Date)

    statement: Mapped["CasStatement"]       = relationship(back_populates="demat_accounts")
    holdings:  Mapped[list["DematHolding"]] = relationship(back_populates="account", cascade="all, delete-orphan")
    transactions: Mapped[list["DematTransaction"]] = relationship(back_populates="account", cascade="all, delete-orphan")


class DematHolding(Base):
    __tablename__ = "demat_holdings"

    holding_id:    Mapped[uuid.UUID]   = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    account_id:    Mapped[uuid.UUID]   = mapped_column(UUID(as_uuid=True), ForeignKey("demat_accounts.account_id", ondelete="CASCADE"), nullable=False)
    statement_id:  Mapped[uuid.UUID]   = mapped_column(UUID(as_uuid=True), ForeignKey("cas_statements.statement_id", ondelete="CASCADE"), nullable=False)
    isin:          Mapped[str]         = mapped_column(String(12), nullable=False)
    security_name: Mapped[str | None]  = mapped_column(Text)
    trading_symbol: Mapped[str | None] = mapped_column(String(20))
    asset_class:   Mapped[str | None]  = mapped_column(String(20))
    quantity:      Mapped[Decimal]     = mapped_column(Numeric(18, 6), nullable=False)
    market_price:  Mapped[Decimal | None] = mapped_column(Numeric(18, 4))
    current_value: Mapped[Decimal | None] = mapped_column(Numeric(18, 2))

    account: Mapped["DematAccount"] = relationship(back_populates="holdings")


class DematTransaction(Base):
    __tablename__ = "demat_transactions"

    txn_id:          Mapped[uuid.UUID]   = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    account_id:      Mapped[uuid.UUID]   = mapped_column(UUID(as_uuid=True), ForeignKey("demat_accounts.account_id", ondelete="CASCADE"), nullable=False)
    statement_id:    Mapped[uuid.UUID]   = mapped_column(UUID(as_uuid=True), ForeignKey("cas_statements.statement_id", ondelete="CASCADE"), nullable=False)
    isin:            Mapped[str | None]  = mapped_column(String(12))
    txn_date:        Mapped[date]        = mapped_column(Date, nullable=False)
    description:     Mapped[str | None]  = mapped_column(Text)
    credit_units:    Mapped[Decimal | None] = mapped_column(Numeric(18, 6))
    debit_units:     Mapped[Decimal | None] = mapped_column(Numeric(18, 6))
    closing_balance: Mapped[Decimal | None] = mapped_column(Numeric(18, 6))

    account: Mapped["DematAccount"] = relationship(back_populates="transactions")


class MfFolio(Base):
    __tablename__ = "mf_folios"

    folio_id:     Mapped[uuid.UUID]  = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    statement_id: Mapped[uuid.UUID]  = mapped_column(UUID(as_uuid=True), ForeignKey("cas_statements.statement_id", ondelete="CASCADE"), nullable=False)
    folio_number: Mapped[str]        = mapped_column(Text, nullable=False)
    amc_name:     Mapped[str | None] = mapped_column(Text)
    kyc_status:   Mapped[str | None] = mapped_column(String(20))
    nominee:      Mapped[str | None] = mapped_column(Text)

    statement: Mapped["CasStatement"]  = relationship(back_populates="mf_folios")
    schemes:   Mapped[list["MfScheme"]] = relationship(back_populates="folio", cascade="all, delete-orphan")


class MfScheme(Base):
    __tablename__ = "mf_schemes"

    scheme_id:            Mapped[uuid.UUID]   = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    folio_id:             Mapped[uuid.UUID]   = mapped_column(UUID(as_uuid=True), ForeignKey("mf_folios.folio_id", ondelete="CASCADE"), nullable=False)
    statement_id:         Mapped[uuid.UUID]   = mapped_column(UUID(as_uuid=True), ForeignKey("cas_statements.statement_id", ondelete="CASCADE"), nullable=False)
    isin:                 Mapped[str | None]  = mapped_column(String(12))
    scheme_name_raw:      Mapped[str | None]  = mapped_column(Text)
    scheme_name:          Mapped[str | None]  = mapped_column(Text)
    face_value:           Mapped[Decimal | None] = mapped_column(Numeric(10, 2))
    units:                Mapped[Decimal | None] = mapped_column(Numeric(18, 6))
    nav:                  Mapped[Decimal | None] = mapped_column(Numeric(14, 6))
    current_value:        Mapped[Decimal | None] = mapped_column(Numeric(18, 2))
    invested_value:       Mapped[Decimal | None] = mapped_column(Numeric(18, 2))
    gain_loss:            Mapped[Decimal | None] = mapped_column(Numeric(18, 2))
    extraction_confidence: Mapped[Decimal | None] = mapped_column(Numeric(4, 3))

    folio:        Mapped["MfFolio"]           = relationship(back_populates="schemes")
    transactions: Mapped[list["MfTransaction"]] = relationship(back_populates="scheme", cascade="all, delete-orphan")


class MfTransaction(Base):
    __tablename__ = "mf_transactions"

    txn_id:      Mapped[uuid.UUID]   = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    scheme_id:   Mapped[uuid.UUID]   = mapped_column(UUID(as_uuid=True), ForeignKey("mf_schemes.scheme_id", ondelete="CASCADE"), nullable=False)
    statement_id: Mapped[uuid.UUID]  = mapped_column(UUID(as_uuid=True), ForeignKey("cas_statements.statement_id", ondelete="CASCADE"), nullable=False)
    txn_date:    Mapped[date]        = mapped_column(Date, nullable=False)
    txn_type:    Mapped[str | None]  = mapped_column(String(20))
    amount:      Mapped[Decimal | None] = mapped_column(Numeric(18, 2))
    units:       Mapped[Decimal | None] = mapped_column(Numeric(18, 6))
    nav:         Mapped[Decimal | None] = mapped_column(Numeric(14, 6))

    scheme: Mapped["MfScheme"] = relationship(back_populates="transactions")
