"""Persist parsed CAS statements to PostgreSQL.

Duplicate prevention strategy:
  - Level 1 (same parse_id): idempotent no-op — same UUID won't insert twice
  - Level 2 (same client + provider + statement_date): upsert — delete old
    children and replace with fresh data from the new parse
  - Level 3 (ISIN within a statement): holdings deduplicated by ISIN per account
"""
import uuid

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import models as db
from app.models.statement import Statement


class StatementRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def save_statement(self, statement: Statement, source_filename: str | None = None) -> db.CasStatement:
        firm_id = statement.firm_id or "DEFAULT"
        client_ref = statement.client_id or "UNKNOWN"

        firm = await self._get_or_create_firm(firm_id)
        client = await self._get_or_create_client(firm.firm_id, client_ref, statement)

        # Level 1: same parse_id → already stored, nothing to do
        by_parse_id = await self.session.scalar(
            select(db.CasStatement).where(db.CasStatement.parse_id == statement.parse_id)
        )
        if by_parse_id:
            return by_parse_id

        # Level 2: same client + provider + statement_date → replace previous parse
        provider_value = statement.provider.name.value
        stmt_date = statement.statement.statement_date
        existing = await self.session.scalar(
            select(db.CasStatement).where(
                db.CasStatement.client_id == client.client_id,
                db.CasStatement.provider == provider_value,
                db.CasStatement.statement_date == stmt_date,
            )
        ) if stmt_date else None

        if existing:
            # Delete all children first (cascade would also work, but explicit is clearer)
            await self.session.execute(
                delete(db.DematAccount).where(db.DematAccount.statement_id == existing.statement_id)
            )
            await self.session.execute(
                delete(db.MfFolio).where(db.MfFolio.statement_id == existing.statement_id)
            )
            await self.session.delete(existing)
            await self.session.flush()

        cas = db.CasStatement(
            firm_id=firm.firm_id,
            client_id=client.client_id,
            parse_id=statement.parse_id,
            provider=provider_value,
            depository=provider_value if provider_value in ("CDSL", "NSDL") else None,
            statement_date=stmt_date,
            investor_name=statement.investor.name,
            investor_pan=statement.investor.pan_masked,
            investor_email=statement.investor.email,
            investor_mobile=statement.investor.mobile,
            parse_status=statement.status,
            parse_confidence=statement.confidence.get("overall") if statement.confidence else None,
            provider_signals=statement.provider.signals or [],
            source_filename=source_filename,
            firm_code=firm_id,
            client_ref=client_ref,
            raw_warnings=list((statement.validation or {}).get("warnings", [])),
        )
        self.session.add(cas)
        await self.session.flush()

        # Demat accounts + holdings (Level 3: deduplicate ISINs per account)
        for acct in statement.demat_accounts:
            total_value = sum(float(h.current_value or 0) for h in acct.holdings)
            db_acct = db.DematAccount(
                statement_id=cas.statement_id,
                depository=acct.depository,
                dp_name=acct.dp_name,
                dp_id=acct.dp_id,
                demat_client_id=acct.client_id,
                account_value=total_value if total_value else None,
                as_of_date=stmt_date,
            )
            self.session.add(db_acct)
            await self.session.flush()

            seen_isins: set[str] = set()
            for h in acct.holdings:
                if h.isin in seen_isins:
                    continue  # skip duplicate ISIN within same account
                seen_isins.add(h.isin)
                self.session.add(db.DematHolding(
                    account_id=db_acct.account_id,
                    statement_id=cas.statement_id,
                    isin=h.isin,
                    security_name=h.security_name,
                    trading_symbol=h.trading_symbol,
                    quantity=h.quantity,
                    market_price=h.market_price,
                    current_value=h.current_value,
                ))

            for txn in acct.transactions:
                self.session.add(db.DematTransaction(
                    account_id=db_acct.account_id,
                    statement_id=cas.statement_id,
                    isin=txn.isin,
                    txn_date=txn.date,
                    description=txn.description,
                    credit_units=txn.credit_units,
                    debit_units=txn.debit_units,
                    closing_balance=txn.closing_balance,
                ))

        # MF folios + schemes
        for folio_data in statement.folios:
            folio_dict = folio_data if isinstance(folio_data, dict) else folio_data.model_dump()
            db_folio = db.MfFolio(
                statement_id=cas.statement_id,
                folio_number=folio_dict.get("folio_number", ""),
                amc_name=folio_dict.get("amc_name"),
                kyc_status=folio_dict.get("kyc_status"),
                nominee=folio_dict.get("nominee"),
            )
            self.session.add(db_folio)
            await self.session.flush()

            for scheme_dict in folio_dict.get("schemes", []):
                db_scheme = db.MfScheme(
                    folio_id=db_folio.folio_id,
                    statement_id=cas.statement_id,
                    isin=scheme_dict.get("isin"),
                    scheme_name_raw=scheme_dict.get("scheme_name_raw"),
                    scheme_name=scheme_dict.get("scheme_name_normalized"),
                    face_value=scheme_dict.get("face_value"),
                    units=scheme_dict.get("units"),
                    nav=scheme_dict.get("nav"),
                    current_value=scheme_dict.get("current_value"),
                    invested_value=scheme_dict.get("invested_value"),
                    gain_loss=scheme_dict.get("gain_loss"),
                    extraction_confidence=scheme_dict.get("confidence"),
                )
                self.session.add(db_scheme)
                await self.session.flush()

                for txn_dict in scheme_dict.get("transactions", []):
                    self.session.add(db.MfTransaction(
                        scheme_id=db_scheme.scheme_id,
                        statement_id=cas.statement_id,
                        txn_date=txn_dict.get("date"),
                        txn_type=txn_dict.get("type"),
                        amount=txn_dict.get("amount"),
                        units=txn_dict.get("units"),
                        nav=txn_dict.get("nav"),
                    ))

        await self.session.commit()
        return cas

    async def _get_or_create_firm(self, firm_code: str) -> db.Firm:
        firm = await self.session.scalar(
            select(db.Firm).where(db.Firm.firm_code == firm_code)
        )
        if firm is None:
            firm = db.Firm(firm_code=firm_code, firm_name=firm_code)
            self.session.add(firm)
            await self.session.flush()
        return firm

    async def _get_or_create_client(
        self, firm_id: uuid.UUID, external_ref: str, statement: Statement
    ) -> db.Client:
        client = await self.session.scalar(
            select(db.Client).where(
                db.Client.firm_id == firm_id,
                db.Client.external_ref == external_ref,
            )
        )
        if client is None:
            client = db.Client(
                firm_id=firm_id,
                external_ref=external_ref,
                full_name=statement.investor.name,
                pan=statement.investor.pan_masked,
                email=statement.investor.email,
                mobile=statement.investor.mobile,
            )
            self.session.add(client)
            await self.session.flush()
        return client
