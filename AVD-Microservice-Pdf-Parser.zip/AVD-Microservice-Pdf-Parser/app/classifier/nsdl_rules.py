from decimal import Decimal

from app.classifier.base import ProviderRule
from app.models.document import ExtractedDocument
from app.models.enums import Provider
from app.models.statement import ProviderDetection


class NSDLRules(ProviderRule):
    provider = Provider.NSDL

    def score(self, document: ExtractedDocument) -> ProviderDetection:
        text = document.text.lower()
        text_no_spaces = text.replace(" ", "")

        signals: list[str] = []
        score = 0

        # "NSDL ID:" is exclusive to NSDL — dominant signal
        if "nsdl id:" in text:
            score += 90
            signals.append("nsdl_id_found")

        # NSDL branding (appears doubled: "nnssddll" after lowercasing doubled chars)
        if "nsdl" in text:
            score += 50
            signals.append("nsdl_keyword_found")

        # "National Securities Depository" — may appear doubled as "nnaattiioonnaall sseeccuurriittiieess"
        if "nationalsecurities" in text_no_spaces or "national securities depository" in text:
            score += 40
            signals.append("nsdl_issuer_found")

        # CAS header with NSDL context
        if "consolidated account statement" in text and "nsdl" in text:
            score += 20
            signals.append("nsdl_cas_header")

        return ProviderDetection(
            name=Provider.NSDL,
            confidence=Decimal(min(score, 100)) / 100,
            signals=signals,
        )
