from decimal import Decimal

from app.classifier.base import ProviderRule
from app.models.document import ExtractedDocument
from app.models.enums import Provider
from app.models.statement import ProviderDetection


class CDSLRules(ProviderRule):
    provider = Provider.CDSL

    def score(self, document: ExtractedDocument) -> ProviderDetection:
        text = document.text.lower()
        # Remove extra spaces for robust matching
        text_no_spaces = text.replace(" ", "")
        
        # Don't score on CDSL keywords if this is clearly an NSDL document
        if "nsdl id:" in text:
            return ProviderDetection(name=Provider.CDSL, confidence=Decimal("0"), signals=[])

        signals: list[str] = []
        score = 0
        
        # CDSL-specific keywords (higher priority)
        if "securities held in demat" in text or "demat account" in text:
            score += 60
            signals.append("demat_account_found")
        
        # CAS ID is CDSL-exclusive — give it dominant weight
        if "casid" in text_no_spaces:
            score += 80
            signals.append("cas_id_found")
        
        # Central Depository (handle space-split corruption like "Ce nt ra l")
        if "centraldepository" in text_no_spaces or "cdsl" in text:
            score += 70
            signals.append("cdsl_issuer_found")
            
        # If we have CAS + demat keywords, it's definitely CDSL
        if "consolidated account statement" in text and ("demat" in text or "casid" in text_no_spaces):
            score += 20
            signals.append("cas_with_demat")
            
        return ProviderDetection(
            name=Provider.CDSL,
            confidence=Decimal(min(score, 100)) / 100,
            signals=signals,
        )
