from pathlib import Path
from uuid import UUID, uuid4

import structlog

from app.classifier.provider_classifier import ProviderClassifier
from app.core.config import get_settings
from app.core.exceptions import UnknownProviderError
from app.extractors.strategy import ExtractionStrategy
from app.models.enums import ParseStatus
from app.models.statement import Investor, Statement, StatementMetadata
from app.parsers.registry import ParserRegistry
from app.parsers.shared.date_utils import parse_cas_date

log = structlog.get_logger()


class ParseService:
    def __init__(self, extractor: ExtractionStrategy, classifier: ProviderClassifier, registry: ParserRegistry) -> None:
        self.extractor = extractor
        self.classifier = classifier
        self.registry = registry

    def parse_file(self, path: Path, parse_id: UUID | None = None, password: str | None = None, firm_id: str | None = None, client_id: str | None = None) -> Statement:
        settings = get_settings()
        document = self.extractor.extract(path, password=password)
        detection = self.classifier.classify(document)
        if detection.name.value == "UNKNOWN":
            raise UnknownProviderError
        raw = self.registry.get_parser(detection.name).parse(document)

        parse_status = ParseStatus.COMPLETED.value if not raw.warnings else ParseStatus.PARTIAL.value
        statement_date = parse_cas_date(raw.statement_date) if raw.statement_date else None

        statement = Statement(
            parse_id=parse_id or uuid4(),
            status=parse_status,
            firm_id=firm_id,
            client_id=client_id,
            provider=detection,
            statement=StatementMetadata(provider=detection.name, statement_date=statement_date),
            investor=Investor(
                name=raw.investor_name,
                pan_masked=raw.investor_pan,
                email=raw.investor_email,
                mobile=raw.investor_mobile,
            ),
            folios=[folio.model_dump() for folio in raw.folios],
            demat_accounts=raw.demat_accounts,
            validation={"is_valid": not any(w.startswith("no_") for w in raw.warnings), "warnings": raw.warnings},
            confidence={"overall": detection.confidence},
        )

        # OpenAI fallback — kick in when confidence is below threshold
        confidence_val = float(detection.confidence)
        if (
            settings.openai_api_key
            and confidence_val < settings.openai_confidence_threshold
        ):
            self._apply_openai_fallback(statement, document.text, settings)

        return statement

    @staticmethod
    def _apply_openai_fallback(statement: Statement, text: str, settings) -> None:
        from app.extractors.openai_fallback import call_openai, merge_openai_into_statement
        try:
            log.info(
                "openai_fallback_triggered",
                confidence=float(statement.confidence.get("overall", 0)),
                threshold=settings.openai_confidence_threshold,
            )
            openai_data = call_openai(text, settings.openai_api_key, settings.openai_model)
            merge_openai_into_statement(statement, openai_data)
            # Mark that OpenAI enrichment was used
            statement.confidence["openai_enriched"] = True
            log.info("openai_fallback_applied", folios=len(openai_data.get("folios", [])))
        except Exception as exc:
            # Never let fallback failure break the main response
            log.warning("openai_fallback_failed", error=str(exc))
