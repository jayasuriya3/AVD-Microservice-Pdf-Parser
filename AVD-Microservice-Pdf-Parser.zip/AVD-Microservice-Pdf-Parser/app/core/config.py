from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    service_name: str = "cas-parser"
    version: str = "0.1.0"
    environment: str = "development"
    max_upload_size_bytes: int = 25 * 1024 * 1024
    min_extracted_characters: int = 20  # raised from 40 – lenient default
    min_chars_per_page: int = 20  # below this a page is treated as scanned
    # When True the parser runs even if quality checks fail (partial results)
    accept_low_quality: bool = False
    reconciliation_tolerance: str = "0.05"

    # ── OCR settings ────────────────────────────────────────────────
    ocr_enabled: bool = False
    # "tesseract" | "rapidocr" | "multi_engine"
    ocr_backend: str = "multi_engine"
    ocr_dpi: int = 300
    ocr_lang: str = "eng"
    # Tesseract per-word confidence threshold (0–100)
    ocr_tesseract_min_confidence: int = 40
    # RapidOCR per-detection confidence threshold (0.0–1.0)
    ocr_rapidocr_min_confidence: float = 0.4

    # ── Optional feature flags ───────────────────────────────────────
    ml_classification_enabled: bool = False
    async_job_processing_enabled: bool = False

    pdf_extractor_backend: str = "pdfplumber+fitz"
    ml_backend: str = "scikit-learn"
    job_queue_backend: str = "celery"

    # ── Persistence ─────────────────────────────────────────────────
    database_url: str = "postgresql+asyncpg://cas_user:cas_secret_2026@localhost:5432/cas_parser"
    redis_url: str = "redis://localhost:6379/0"

    # ── OpenAI fallback ─────────────────────────────────────────────
    openai_api_key: str = ""
    openai_model: str = "gpt-4o-mini"
    # If overall confidence is below this, trigger OpenAI re-extraction
    openai_confidence_threshold: float = 0.7

    model_config = SettingsConfigDict(env_prefix="CAS_PARSER_", env_file=".env", extra="ignore")


@lru_cache
def get_settings() -> Settings:
    return Settings()
