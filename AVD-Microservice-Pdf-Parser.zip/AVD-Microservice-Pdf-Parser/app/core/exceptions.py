class CASParserError(Exception):
    code = "CAS_PARSER_ERROR"
    retryable = False
    hint: str | None = None


class UnsupportedDocumentError(CASParserError):
    code = "UNSUPPORTED_DOCUMENT"


class UnknownProviderError(CASParserError):
    code = "UNKNOWN_PROVIDER"
    hint = "The PDF could not be identified as a CAMS or KFintech CAS statement."


class EncryptedPDFError(CASParserError):
    code = "ENCRYPTED_PDF"
    hint = "Re-upload with the 'password' form field."


class CorruptedPDFError(CASParserError):
    code = "CORRUPTED_PDF"


class LowQualityExtractionError(CASParserError):
    code = "LOW_QUALITY_EXTRACTION"
    retryable = True  # can be retried after enabling OCR
    hint = (
        "The PDF appears to be a scanned image. "
        "Enable OCR by setting CAS_PARSER_OCR_ENABLED=true and "
        "installing optional OCR dependencies: "
        "pip install 'advisordesk-cas-parser[ocr]'"
    )

    def __init__(self, chars_extracted: int = 0, pages: int = 0) -> None:
        super().__init__()
        self.chars_extracted = chars_extracted
        self.pages = pages


class ParserFailureError(CASParserError):
    code = "PARSER_FAILURE"
    retryable = True


class ValidationFailureError(CASParserError):
    code = "VALIDATION_FAILURE"
