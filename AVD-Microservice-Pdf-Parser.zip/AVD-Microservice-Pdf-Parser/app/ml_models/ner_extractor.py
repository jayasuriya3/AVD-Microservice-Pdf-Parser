"""
Local NER-based financial document extractor.
Uses HuggingFace transformers (no API keys needed, runs locally).
"""
from decimal import Decimal
from typing import Any

from app.models.folio import Folio, Scheme
from app.models.statement import Statement, Investor


class FinancialNERExtractor:
    """
    Extract financial entities from CAS text using local NER model.
    Supports: investor name, PAN, dates, folios, schemes, amounts, units.
    """

    def __init__(self):
        """Initialize HuggingFace transformers (downloads model once, then cached locally)."""
        try:
            from transformers import pipeline
            # Use a pre-trained financial/general NER model
            # dbmdz/bert-base-multilingual-uncased works for multiple languages
            self.ner_pipeline = pipeline(
                "token-classification",
                model="dslim/bert-base-uncased-finetuned-ner",  # General NER
                aggregation_strategy="simple",
                device=0 if self._cuda_available() else -1  # GPU if available, else CPU
            )
            self.available = True
        except ImportError:
            self.available = False
            print("WARNING: transformers not installed. Install with: pip install transformers torch")

    @staticmethod
    def _cuda_available() -> bool:
        """Check if GPU is available."""
        try:
            import torch
            return torch.cuda.is_available()
        except ImportError:
            return False

    def extract_investor_name(self, text: str) -> str | None:
        """Extract investor name from text using pattern + NER."""
        lines = text.split('\n')
        
        # Pattern: "CAS ID: ...\n{NAME}" (CAS header line followed by name)
        for i, line in enumerate(lines):
            if 'cas' in line.lower() and 'id' in line.lower():
                if i + 1 < len(lines):
                    name_candidate = lines[i + 1].strip()
                    if name_candidate and len(name_candidate) > 2:
                        return name_candidate
        
        # Fallback: Use NER to find PERSON entities
        if self.available:
            try:
                entities = self.ner_pipeline(text[:512])  # Limit to first 512 chars for performance
                persons = [e for e in entities if e['entity_group'] == 'PER']
                if persons:
                    return persons[0]['word'].strip()
            except Exception:
                pass
        
        return None

    def extract_pan(self, text: str) -> str | None:
        """Extract PAN (10-digit alphanumeric) from text."""
        import re
        # PAN format: AAAAA9999A (5 letters, 4 digits, 1 letter)
        pan_pattern = r'[A-Z]{5}[0-9]{4}[A-Z]{1}'
        match = re.search(pan_pattern, text.upper())
        return match.group(0) if match else None

    def extract_statement_date(self, text: str) -> str | None:
        """Extract statement date from text."""
        import re
        # Formats: DD-MM-YYYY, DD/MM/YYYY, etc.
        date_pattern = r'\d{2}[-/]\d{2}[-/]\d{4}'
        match = re.search(date_pattern, text)
        return match.group(0) if match else None

    def extract_isin(self, text: str) -> list[str]:
        """Extract ISINs (12-char codes starting with IN) from text."""
        import re
        isin_pattern = r'IN[A-Z0-9]{10}'
        return re.findall(isin_pattern, text.upper())

    def extract_decimal_values(self, text: str) -> list[Decimal]:
        """Extract all numeric values (prices, units, NAVs) from text."""
        import re
        # Match numbers: 123.45, 1234, 0.5, etc.
        number_pattern = r'\d+(?:\.\d{1,4})?'
        matches = re.findall(number_pattern, text)
        return [Decimal(m) for m in matches]

    def extract_folio_scheme_mapping(self, text: str) -> dict[str, list[dict]]:
        """
        Extract folio → schemes mapping using patterns + NER.
        Returns: {"41418985/45": [{"scheme_name": "...", "isin": "..."}]}
        """
        import re
        
        result = {}
        
        # Pattern: Folio Number: XXXXX/YY
        folio_pattern = r'Folio[:\s]+(\d+/\d+)'
        folios = re.findall(folio_pattern, text, re.IGNORECASE)
        
        for folio in folios:
            result[folio] = []
        
        # For each folio, find following ISINs until next folio
        folio_blocks = re.split(r'Folio[:\s]+\d+/\d+', text, flags=re.IGNORECASE)
        
        isins = self.extract_isin(text)
        if isins:
            for folio in folios:
                result[folio] = [{"isin": isin} for isin in isins[:2]]  # Simplification
        
        return result

    def extract_all(self, text: str) -> dict[str, Any]:
        """
        Extract all financial entities from CAS document text.
        Returns dictionary with all extracted fields.
        """
        return {
            "investor_name": self.extract_investor_name(text),
            "pan": self.extract_pan(text),
            "statement_date": self.extract_statement_date(text),
            "isins": self.extract_isin(text),
            "numeric_values": self.extract_decimal_values(text),
            "folio_schemes": self.extract_folio_scheme_mapping(text),
        }
