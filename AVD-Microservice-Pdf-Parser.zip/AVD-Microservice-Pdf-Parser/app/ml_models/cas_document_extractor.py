"""
Fine-tunable transformer model for CAS document parsing.
Can be trained with your own labeled examples.
"""
from typing import Any

import torch
from torch import nn
from transformers import AutoTokenizer, AutoModel


class CASDocumentExtractor(nn.Module):
    """
    Neural model for extracting structured data from CAS documents.
    Based on DistilBERT (lightweight, free to run locally).
    """

    def __init__(self, model_name: str = "distilbert-base-uncased"):
        super().__init__()
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.encoder = AutoModel.from_pretrained(model_name)
        self.hidden_size = self.encoder.config.hidden_size
        
        # Output heads for different entity types
        self.investor_name_head = nn.Sequential(
            nn.Linear(self.hidden_size, 256),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(256, 1)  # Probability that this token is part of investor name
        )
        
        self.isin_head = nn.Sequential(
            nn.Linear(self.hidden_size, 256),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(256, 1)  # Probability that this token is part of ISIN
        )
        
        self.amount_head = nn.Sequential(
            nn.Linear(self.hidden_size, 256),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(256, 1)  # Probability that this token is part of amount
        )

    def forward(self, text: str) -> dict[str, Any]:
        """
        Process CAS document text and extract entities.
        
        Args:
            text: Raw document text
            
        Returns:
            Dictionary with extracted fields
        """
        # Tokenize
        inputs = self.tokenizer(
            text,
            return_tensors="pt",
            max_length=512,
            truncation=True,
            padding=True
        )
        
        # Get embeddings from encoder
        with torch.no_grad():
            outputs = self.encoder(**inputs)
            embeddings = outputs.last_hidden_state  # [batch_size, seq_len, hidden_size]
        
        # Apply extraction heads
        investor_scores = self.investor_name_head(embeddings).squeeze(-1)
        isin_scores = self.isin_head(embeddings).squeeze(-1)
        amount_scores = self.amount_head(embeddings).squeeze(-1)
        
        # Decode predictions back to text
        tokens = self.tokenizer.convert_ids_to_tokens(inputs['input_ids'][0])
        
        # Extract entities by finding high-score regions
        entities = {
            "investor_names": self._extract_entity(tokens, investor_scores[0], threshold=0.5),
            "isins": self._extract_entity(tokens, isin_scores[0], threshold=0.5),
            "amounts": self._extract_entity(tokens, amount_scores[0], threshold=0.5),
        }
        
        return entities

    @staticmethod
    def _extract_entity(tokens: list[str], scores: torch.Tensor, threshold: float = 0.5) -> list[str]:
        """Extract consecutive high-scoring tokens as entities."""
        entities = []
        current_entity = []
        
        for token, score in zip(tokens, scores):
            if score > threshold and token not in ['[CLS]', '[SEP]', '[PAD]']:
                # Clean up subword tokens
                clean_token = token.replace('##', '').strip()
                if clean_token:
                    current_entity.append(clean_token)
            else:
                if current_entity:
                    entities.append(' '.join(current_entity))
                    current_entity = []
        
        if current_entity:
            entities.append(' '.join(current_entity))
        
        return entities

    def save(self, path: str):
        """Save model checkpoint."""
        torch.save(self.state_dict(), path)

    @classmethod
    def load(cls, path: str, model_name: str = "distilbert-base-uncased"):
        """Load model from checkpoint."""
        model = cls(model_name)
        model.load_state_dict(torch.load(path))
        return model

    def to_device(self, device: str = "cuda" if torch.cuda.is_available() else "cpu"):
        """Move model to device (GPU or CPU)."""
        return self.to(device)
