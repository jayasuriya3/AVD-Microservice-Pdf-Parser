"""
Generate training dataset for CAS document extraction.
Creates realistic labeled examples for fine-tuning the ML model.
"""
import json
from pathlib import Path
from typing import Any

TRAINING_SAMPLES = [
    # CDSL - Equity Heavy with Demat
    {
        "text": """
CONSOLIDATED ACCOUNT STATEMENT (CAS)
FOR SECURITIES HELD IN DEMAT
Period: 01-07-2026 to 31-07-2026

CAS ID: 123456789012

Name: Jayasuriya S
PAN: CEUPJ9812H
Email: suriyashan98@gmail.com
Mobile: 9876543210

Folio No: 41418985/45
Scheme Name: ICICI Prudential Equity & Debt Fund - Growth
ISIN: INF109K01480
Units: 11.177
NAV: 408.33
Value: 4563.90
SIP Active: Yes

Folio No: 499475281106/0
Scheme Name: NIPPON INDIA GOLD SAVINGS FUND - GROWTH PLAN
ISIN: INF204K01KN0
Units: 52.218
NAV: 53.8626
Value: 2812.60

Demat Accounts:
DP Name: ZERODHA BROKING LIMITED
DP ID: 12081600
Client ID: 57802693

Holdings:
ISIN: INE885A01032, Security: Amara Raja Energy & Mobility Limited, Qty: 2.000, Price: 910.35
ISIN: INE208A01029, Security: Ashok Leyland Limited, Qty: 90.000, Price: 166.10
ISIN: INE089A01031, Security: Dr. Reddy's Laboratories Limited, Qty: 28.000, Price: 1147.60
""",
        "investor_name": "Jayasuriya S",
        "pan": "CEUPJ9812H",
        "email": "suriyashan98@gmail.com",
        "mobile": "9876543210",
        "statement_date": "31-07-2026",
        "isins": ["INF109K01480", "INF204K01KN0", "INE885A01032", "INE208A01029", "INE089A01031"],
        "folios": ["41418985/45", "499475281106/0"],
        "provider": "CDSL",
        "securities": [
            {"isin": "INE885A01032", "name": "Amara Raja Energy & Mobility Limited", "qty": 2.0, "price": 910.35},
            {"isin": "INE208A01029", "name": "Ashok Leyland Limited", "qty": 90.0, "price": 166.10},
            {"isin": "INE089A01031", "name": "Dr. Reddy's Laboratories Limited", "qty": 28.0, "price": 1147.60},
        ],
    },
    # CDSL - Blue Chip Holdings
    {
        "text": """
CONSOLIDATED ACCOUNT STATEMENT (CAS)
FOR SECURITIES HELD IN DEMAT
01-06-2026 to 30-06-2026

CAS ID: 987654321098

Name: Priya Sharma
PAN: ABCDE1234F
Email: priya.sharma@example.com

Folio No: 12345/67
Scheme Name: SBI Bluechip Fund - Direct Growth
ISIN: INF200K01KN0
Units: 25.50
NAV: 150.00
Value: 3825.00

Folio No: 87654/32
Scheme Name: Axis Growth Fund - Direct Plan
ISIN: INF095A01035
Units: 15.75
NAV: 500.00
Value: 7875.00

Demat Accounts:
DP Name: GROWW INVEST TECH PRIVATE LIMITED
DP ID: 12088701
Client ID: 45174536

Holdings:
ISIN: INE040A01034, Security: HDFC Bank Limited, Qty: 5.000, Price: 747.90
ISIN: INE009A01021, Security: Infosys Limited, Qty: 11.000, Price: 1130.00
ISIN: INE467B01029, Security: TCS Limited, Qty: 3.000, Price: 2365.60
ISIN: INE154A01025, Security: ITC Limited, Qty: 172.000, Price: 280.95
""",
        "investor_name": "Priya Sharma",
        "pan": "ABCDE1234F",
        "email": "priya.sharma@example.com",
        "mobile": None,
        "statement_date": "30-06-2026",
        "isins": ["INF200K01KN0", "INF095A01035", "INE040A01034", "INE009A01021", "INE467B01029", "INE154A01025"],
        "folios": ["12345/67", "87654/32"],
        "provider": "CDSL",
        "securities": [
            {"isin": "INE040A01034", "name": "HDFC Bank Limited", "qty": 5.0, "price": 747.90},
            {"isin": "INE009A01021", "name": "Infosys Limited", "qty": 11.0, "price": 1130.00},
            {"isin": "INE467B01029", "name": "TCS Limited", "qty": 3.0, "price": 2365.60},
            {"isin": "INE154A01025", "name": "ITC Limited", "qty": 172.0, "price": 280.95},
        ],
    },
    # CDSL - Pharma & Midcap Focus
    {
        "text": """
CONSOLIDATED ACCOUNT STATEMENT (CAS)
FOR SECURITIES HELD IN DEMAT
FOR THE PERIOD: 15-05-2026 TO 15-06-2026

CAS ID: 555555555555

Name: Rajesh Kumar
PAN: RSTXY5678Z
Email: rajesh.k@mail.com
Mobile: 8765432109

Folio: 55555/88

Scheme 1: HDFC Mutual Fund - Large Cap Fund
ISIN: INF109A01034
Valuation Date: 15-06-2026
Number of Units: 50.00
Net Asset Value: 300.00
Current Value: 15000.00

Scheme 2: ICICI Prudential Balanced Advantage Fund
ISIN: INF109K01LD0
Valuation Date: 15-06-2026
Number of Units: 100.00
Net Asset Value: 200.00
Current Value: 20000.00

Demat Holdings:
DP Name: INDSTOCKS PRIVATE LIMITED
DP ID: 12095500

Holdings:
ISIN: INF109KC11M9, Qty: 459.450, Price: 20.4040
ISIN: INE092T01019, Qty: 528.000, Price: 84.7000
ISIN: INE095A01012, Qty: 7.000, Price: 1012.9000
""",
        "investor_name": "Rajesh Kumar",
        "pan": "RSTXY5678Z",
        "email": "rajesh.k@mail.com",
        "mobile": "8765432109",
        "statement_date": "15-06-2026",
        "isins": ["INF109A01034", "INF109K01LD0", "INF109KC11M9", "INE092T01019", "INE095A01012"],
        "folios": ["55555/88"],
        "provider": "CDSL",
        "securities": [
            {"isin": "INF109KC11M9", "name": "ICICI Prudential Nifty Pharma Index Fund - Direct Growth", "qty": 459.45, "price": 20.4040},
            {"isin": "INE092T01019", "name": "IDFC First Bank Limited", "qty": 528.0, "price": 84.7},
            {"isin": "INE095A01012", "name": "IndusInd Bank Limited", "qty": 7.0, "price": 1012.9},
        ],
    },
    # CAMS - Mutual Fund Heavy Portfolio
    {
        "text": """
CONSOLIDATED ACCOUNT STATEMENT
Period: 01-04-2026 to 30-04-2026

CAMS COMPUTER AGE MANAGEMENT SERVICES PRIVATE LIMITED
Registrar and Transfer Agent

Investor Details:
Name: Vikram Singh
PAN: PQRST4567U
Email: vikram.singh@corporate.com
Mobile: 7654321098

Statement Date: 30-04-2026

Scheme: Axis Bluechip Fund - Direct Growth
Folio Number: 54321/12
ISIN: INF095A01058
Units Held: 125.500
NAV: 42.50
Current Value: 5333.87

Scheme: Aditya Birla Sun Life Equity Fund - Direct Growth
Folio Number: 54321/13
ISIN: INF209A01029
Units Held: 75.250
NAV: 58.75
Current Value: 4421.40

Scheme: DSP Top 100 Equity Fund - Direct Growth
Folio Number: 54321/14
ISIN: INF740A01076
Units Held: 40.000
NAV: 125.00
Current Value: 5000.00
""",
        "investor_name": "Vikram Singh",
        "pan": "PQRST4567U",
        "email": "vikram.singh@corporate.com",
        "mobile": "7654321098",
        "statement_date": "30-04-2026",
        "isins": ["INF095A01058", "INF209A01029", "INF740A01076"],
        "folios": ["54321/12", "54321/13", "54321/14"],
        "provider": "CAMS",
        "securities": [
            {"isin": "INF095A01058", "name": "Axis Bluechip Fund - Direct Growth", "qty": 125.5, "price": 42.50},
            {"isin": "INF209A01029", "name": "Aditya Birla Sun Life Equity Fund - Direct Growth", "qty": 75.25, "price": 58.75},
            {"isin": "INF740A01076", "name": "DSP Top 100 Equity Fund - Direct Growth", "qty": 40.0, "price": 125.00},
        ],
    },
    # CAMS - Long-term SIP Portfolio
    {
        "text": """
CONSOLIDATED ACCOUNT STATEMENT
Statement For: 01-03-2026 To 31-03-2026

CAMS - COMPUTER AGE MANAGEMENT SERVICES
Registrar and Transfer Agent

Name: Anita Patel
PAN: LMNOP6789Q
Email: anita.patel@email.com

Statement Date: 31-03-2026

Investment Details:

Scheme Name: SBI Equity Hybrid Fund - Direct Growth
Folio: 99999/45
ISIN: INF200A01062
Units: 250.750
NAV: 65.00
Amount: 16298.75
SIP Monthly Amount: 5000
SIP Status: Active

Scheme Name: Kotak Standard Multicap Fund - Direct Growth
Folio: 99999/46
ISIN: INF209B01016
Units: 180.500
NAV: 45.25
Amount: 8166.12

Scheme Name: Franklin India Focused Equity Fund - Direct Growth
Folio: 99999/47
ISIN: INF075A01023
Units: 95.250
NAV: 125.75
Amount: 11974.18
""",
        "investor_name": "Anita Patel",
        "pan": "LMNOP6789Q",
        "email": "anita.patel@email.com",
        "mobile": None,
        "statement_date": "31-03-2026",
        "isins": ["INF200A01062", "INF209B01016", "INF075A01023"],
        "folios": ["99999/45", "99999/46", "99999/47"],
        "provider": "CAMS",
        "securities": [
            {"isin": "INF200A01062", "name": "SBI Equity Hybrid Fund - Direct Growth", "qty": 250.75, "price": 65.00},
            {"isin": "INF209B01016", "name": "Kotak Standard Multicap Fund - Direct Growth", "qty": 180.5, "price": 45.25},
            {"isin": "INF075A01023", "name": "Franklin India Focused Equity Fund - Direct Growth", "qty": 95.25, "price": 125.75},
        ],
    },
    # KFintech - Diverse Holdings
    {
        "text": """
CONSOLIDATED ACCOUNT STATEMENT
Reporting Period: 01-02-2026 to 29-02-2026

KFINTECH PRIVATE LIMITED
Registrar and Transfer Agent

Client Name: Neha Gupta
PAN Number: GHIJK2345L
Contact Email: neha.gupta@startup.com
Contact Mobile: 6543210987

Account Statement Date: 29-02-2026

Mutual Fund Holdings:

Scheme: Mirae Asset Emerging Bluechip Fund - Direct Growth
Folio No: 11111/99
ISIN Code: INF113A01029
Units Holding: 88.450
Current NAV: 157.50
Current Value: 13941.97

Scheme: Parag Parikh Financial Advisory Services - Direct Growth
Folio No: 11111/100
ISIN Code: INF229A01046
Units Holding: 105.680
Current NAV: 85.00
Current Value: 8982.80

Scheme: HDFC Large Cap Fund - Direct Growth
Folio No: 11111/101
ISIN Code: INF179A01029
Units Holding: 45.320
Current NAV: 210.50
Current Value: 9532.86

Scheme: Motilal Oswal Multicap 35 Fund - Direct Growth
Folio No: 11111/102
ISIN Code: INF836A01023
Units Holding: 72.150
Current NAV: 95.75
Current Value: 6910.11
""",
        "investor_name": "Neha Gupta",
        "pan": "GHIJK2345L",
        "email": "neha.gupta@startup.com",
        "mobile": "6543210987",
        "statement_date": "29-02-2026",
        "isins": ["INF113A01029", "INF229A01046", "INF179A01029", "INF836A01023"],
        "folios": ["11111/99", "11111/100", "11111/101", "11111/102"],
        "provider": "KFINTECH",
        "securities": [
            {"isin": "INF113A01029", "name": "Mirae Asset Emerging Bluechip Fund - Direct Growth", "qty": 88.45, "price": 157.50},
            {"isin": "INF229A01046", "name": "Parag Parikh Financial Advisory Services - Direct Growth", "qty": 105.68, "price": 85.00},
            {"isin": "INF179A01029", "name": "HDFC Large Cap Fund - Direct Growth", "qty": 45.32, "price": 210.50},
            {"isin": "INF836A01023", "name": "Motilal Oswal Multicap 35 Fund - Direct Growth", "qty": 72.15, "price": 95.75},
        ],
    },
    # KFintech - Balanced & Debt Portfolio
    {
        "text": """
CONSOLIDATED ACCOUNT STATEMENT
For Period 01-01-2026 To 31-01-2026

KFINTECH PRIVATE LIMITED
Registrar and Transfer Agent

Name: Ravi Deshmukh
PAN: MNOPQ3456R
Email: ravi.deshmukh@business.com

Statement Date: 31-01-2026

Folio Holdings:

Scheme: Nippon India Nifty 50 Index Fund - Direct Growth
Folio: 22222/55
ISIN: INF204A01099
Units: 320.250
NAV: 34.75
Value: 11129.69

Scheme: Vanguard India Total Bond Fund - Direct Growth
Folio: 22222/56
ISIN: INF846A01057
Units: 150.000
NAV: 18.50
Value: 2775.00

Scheme: HDFC Balanced Growth Fund - Direct Growth
Folio: 22222/57
ISIN: INF179A01051
Units: 95.750
NAV: 87.25
Value: 8356.18

Scheme: SBI Savings Fund - Direct Growth
Folio: 22222/58
ISIN: INF200A01079
Units: 500.000
NAV: 10.00
Value: 5000.00
""",
        "investor_name": "Ravi Deshmukh",
        "pan": "MNOPQ3456R",
        "email": "ravi.deshmukh@business.com",
        "mobile": None,
        "statement_date": "31-01-2026",
        "isins": ["INF204A01099", "INF846A01057", "INF179A01051", "INF200A01079"],
        "folios": ["22222/55", "22222/56", "22222/57", "22222/58"],
        "provider": "KFINTECH",
        "securities": [
            {"isin": "INF204A01099", "name": "Nippon India Nifty 50 Index Fund - Direct Growth", "qty": 320.25, "price": 34.75},
            {"isin": "INF846A01057", "name": "Vanguard India Total Bond Fund - Direct Growth", "qty": 150.0, "price": 18.50},
            {"isin": "INF179A01051", "name": "HDFC Balanced Growth Fund - Direct Growth", "qty": 95.75, "price": 87.25},
            {"isin": "INF200A01079", "name": "SBI Savings Fund - Direct Growth", "qty": 500.0, "price": 10.00},
        ],
    },
    # CDSL - International Investor
    {
        "text": """
CONSOLIDATED ACCOUNT STATEMENT (CAS)
FOR SECURITIES HELD IN DEMAT
01-08-2026 to 31-08-2026

CAS ID: 777777777777

Name: Robert Mitchell
PAN: UVWXY7890Z
Email: robert.mitchell@global.com
Mobile: 919876543210

Folio No: 33333/22
Scheme Name: ICICI Prudential Nifty 100 Index Fund - Direct Growth
ISIN: INF109K01H56
Units: 250.500
NAV: 75.50
Value: 18913.27

Folio No: 33333/23
Scheme Name: Axis Midcap Fund - Direct Growth
ISIN: INF095A01079
Units: 180.000
NAV: 95.00
Value: 17100.00

Demat Accounts:
DP Name: SHOONYA ONLINE SECURITIES
DP ID: 12090123
Client ID: 98765432

Holdings:
ISIN: INE004A01015, Security: Bajaj Auto Limited, Qty: 12.000, Price: 7890.50
ISIN: INE348A01038, Security: Bharti Airtel Limited, Qty: 150.000, Price: 1245.75
ISIN: INE600A01024, Security: Coal India Limited, Qty: 500.000, Price: 425.50
""",
        "investor_name": "Robert Mitchell",
        "pan": "UVWXY7890Z",
        "email": "robert.mitchell@global.com",
        "mobile": "919876543210",
        "statement_date": "31-08-2026",
        "isins": ["INF109K01H56", "INF095A01079", "INE004A01015", "INE348A01038", "INE600A01024"],
        "folios": ["33333/22", "33333/23"],
        "provider": "CDSL",
        "securities": [
            {"isin": "INE004A01015", "name": "Bajaj Auto Limited", "qty": 12.0, "price": 7890.50},
            {"isin": "INE348A01038", "name": "Bharti Airtel Limited", "qty": 150.0, "price": 1245.75},
            {"isin": "INE600A01024", "name": "Coal India Limited", "qty": 500.0, "price": 425.50},
        ],
    },
    # NRI Portfolio - Minimal Holdings
    {
        "text": """
CONSOLIDATED ACCOUNT STATEMENT
For: 15-08-2026 to 15-08-2026

CAMS COMPUTER AGE MANAGEMENT SERVICES
Registrar and Transfer Agent

Name: Anjali Verma
PAN: FGHIJ8901K
Email: anjali@nri-abroad.com

Statement Date: 15-08-2026

Scheme: HDFC Growth Fund - Direct Growth Plan
Folio Number: 44444/11
ISIN: INF179A01037
Units Held: 25.000
NAV: 156.75
Current Value: 3918.75

Scheme: Reliance Value Fund - Direct Growth Plan
Folio Number: 44444/12
ISIN: INF107A01KP9
Units Held: 15.500
NAV: 42.50
Current Value: 658.75
""",
        "investor_name": "Anjali Verma",
        "pan": "FGHIJ8901K",
        "email": "anjali@nri-abroad.com",
        "mobile": None,
        "statement_date": "15-08-2026",
        "isins": ["INF179A01037", "INF107A01KP9"],
        "folios": ["44444/11", "44444/12"],
        "provider": "CAMS",
        "securities": [
            {"isin": "INF179A01037", "name": "HDFC Growth Fund - Direct Growth Plan", "qty": 25.0, "price": 156.75},
            {"isin": "INF107A01KP9", "name": "Reliance Value Fund - Direct Growth Plan", "qty": 15.5, "price": 42.50},
        ],
    },
]


def generate_training_dataset(output_dir: str = "./training_data") -> None:
    """
    Generate training dataset from realistic CAS examples.
    
    Args:
        output_dir: Directory to save training JSON files
    """
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    # Save individual examples
    for i, sample in enumerate(TRAINING_SAMPLES, 1):
        filename = output_path / f"cas_sample_{i:02d}.json"
        with open(filename, "w") as f:
            json.dump(sample, f, indent=2)
        print(f"✅ Created: {filename}")
    
    # Save combined dataset
    combined_file = output_path / "training_dataset.json"
    with open(combined_file, "w") as f:
        json.dump(TRAINING_SAMPLES, f, indent=2)
    print(f"\n✅ Combined dataset: {combined_file}")
    print(f"📊 Total training examples: {len(TRAINING_SAMPLES)}")


def add_pdf_to_dataset(pdf_text: str, metadata: dict[str, Any], output_dir: str = "./training_data") -> None:
    """
    Add a new PDF extraction to training dataset.
    
    Args:
        pdf_text: Extracted text from PDF
        metadata: Labeled fields {
            "investor_name": "...",
            "pan": "...",
            "email": "...",
            "statement_date": "...",
            "folios": [...],
            "isins": [...],
            "provider": "CDSL|CAMS|KFINTECH",
            "securities": [...]
        }
        output_dir: Directory to save
    """
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    # Find next number
    existing = list(output_path.glob("cas_sample_*.json"))
    next_num = len(existing) + 1
    
    sample = {
        "text": pdf_text,
        **metadata
    }
    
    filename = output_path / f"cas_sample_{next_num:02d}.json"
    with open(filename, "w") as f:
        json.dump(sample, f, indent=2)
    
    print(f"✅ Added to dataset: {filename}")


def load_training_dataset(dataset_file: str = "./training_data/training_dataset.json") -> list[dict[str, Any]]:
    """Load training dataset from JSON file."""
    with open(dataset_file, "r") as f:
        return json.load(f)


if __name__ == "__main__":
    # Generate synthetic training data
    generate_training_dataset()
    
    print("\n📚 Training dataset ready!")
    print("Next steps:")
    print("1. Review training_data/*.json files")
    print("2. Add your own labeled PDFs using: add_pdf_to_dataset()")
    print("3. Train model: python -m app.ml_models.trainer")
