"""
Training script for fine-tuning the CAS document extractor model.
You can generate labeled data from your PDFs and train the model locally.
"""
import json
from pathlib import Path
from typing import Any

import torch
from torch.utils.data import Dataset, DataLoader
from torch.optim import AdamW
from torch.nn import CrossEntropyLoss

from app.ml_models.cas_document_extractor import CASDocumentExtractor


class CASSampleDataset(Dataset):
    """
    Dataset for CAS document parsing.
    
    Expected format: List of dicts with:
    {
        "text": "raw document text",
        "investor_name": "John Doe",
        "pan": "AAAAA1111A",
        "isins": ["INE123A01012", "INE456B01023"],
        "amounts": [1000.50, 2500.00],
        "folios": ["12345/01", "67890/02"]
    }
    """

    def __init__(self, examples: list[dict[str, Any]]):
        self.examples = examples

    def __len__(self) -> int:
        return len(self.examples)

    def __getitem__(self, idx: int) -> dict[str, Any]:
        return self.examples[idx]


class CASModelTrainer:
    """Trainer for CAS document extraction model."""

    def __init__(self, model_name: str = "distilbert-base-uncased", device: str = None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.model = CASDocumentExtractor(model_name).to(self.device)
        self.optimizer = AdamW(self.model.parameters(), lr=2e-5)
        self.loss_fn = CrossEntropyLoss()

    def train(
        self,
        training_data: list[dict[str, Any]],
        num_epochs: int = 3,
        batch_size: int = 8,
    ) -> dict[str, Any]:
        """
        Fine-tune model on your labeled CAS documents.
        
        Args:
            training_data: List of labeled examples
            num_epochs: Number of training epochs
            batch_size: Batch size for training
            
        Returns:
            Training metrics
        """
        dataset = CASSampleDataset(training_data)
        dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)
        
        self.model.train()
        total_loss = 0
        
        for epoch in range(num_epochs):
            epoch_loss = 0
            for batch in dataloader:
                # Forward pass
                texts = batch["text"]
                # For each text in batch, extract entities
                predictions = [self.model(text) for text in texts]
                
                # Simplified loss (in production, you'd align predictions to ground truth)
                # This is a placeholder showing the training loop structure
                
                epoch_loss += 0  # Placeholder
            
            avg_loss = epoch_loss / len(dataloader) if len(dataloader) > 0 else 0
            total_loss += avg_loss
            print(f"Epoch {epoch + 1}/{num_epochs} - Loss: {avg_loss:.4f}")
        
        return {"total_loss": total_loss, "avg_loss": total_loss / num_epochs}

    def save_checkpoint(self, path: str):
        """Save trained model."""
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.model.save(path)
        print(f"Model saved to {path}")

    def load_checkpoint(self, path: str):
        """Load trained model."""
        self.model = CASDocumentExtractor.load(path).to(self.device)
        print(f"Model loaded from {path}")


def generate_training_data_from_pdfs(pdf_directory: str) -> list[dict[str, Any]]:
    """
    Generate labeled training data from your PDFs.
    Manual annotation would be needed for best results.
    
    For MVP: Generate synthetic examples from existing regex-parsed results.
    """
    training_examples = [
        {
            "text": "CONSOLIDATED ACCOUNT STATEMENT FOR SECURITIES HELD IN DEMAT\nJohn Doe\nPAN: AAAAA1111A\nFolio: 12345/01\nISIN: INE123A01012\nUnits: 100.50\nNAV: 250.00",
            "investor_name": "John Doe",
            "pan": "AAAAA1111A",
            "isins": ["INE123A01012"],
            "amounts": [100.50, 250.00],
            "folios": ["12345/01"],
        },
        # Add more examples from your actual PDFs
    ]
    return training_examples


if __name__ == "__main__":
    # Example usage
    trainer = CASModelTrainer()
    
    # Generate or load training data
    training_data = generate_training_data_from_pdfs("./pdfs")
    
    # Train model
    metrics = trainer.train(training_data, num_epochs=3, batch_size=4)
    print("Training metrics:", metrics)
    
    # Save trained model
    trainer.save_checkpoint("./models/cas_extractor_v1.pt")
