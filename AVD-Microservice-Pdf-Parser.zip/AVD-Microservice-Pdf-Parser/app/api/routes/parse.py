from pathlib import Path
from tempfile import NamedTemporaryFile
from uuid import UUID, uuid4

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.dependencies import get_parse_service, get_repository
from app.application.parse_service import ParseService
from app.core.config import get_settings
from app.core.exceptions import CASParserError, LowQualityExtractionError
from app.database.connection import get_db
from app.database.repository import StatementRepository
from app.models.responses import ErrorDetail, ErrorResponse, InspectResponse
from app.models.statement import Statement
from app.repositories.in_memory import InMemoryParseRepository

router = APIRouter(prefix="/v1", tags=["parsing"])


@router.post("/parse", response_model=Statement, responses={400: {"model": ErrorResponse}})
async def parse_pdf(
    file: UploadFile = File(...),
    password: str | None = Form(default=None),
    firm_id: str | None = Form(default=None),
    client_id: str | None = Form(default=None),
    service: ParseService = Depends(get_parse_service),
    repository: InMemoryParseRepository = Depends(get_repository),
    db: AsyncSession = Depends(get_db),
) -> Statement:
    settings = get_settings()
    if file.content_type not in {"application/pdf", "application/octet-stream"}:
        raise HTTPException(status_code=415, detail="Only PDF uploads are supported")
    payload = await file.read(settings.max_upload_size_bytes + 1)
    if len(payload) > settings.max_upload_size_bytes:
        raise HTTPException(status_code=413, detail="PDF exceeds configured size limit")
    if not payload.startswith(b"%PDF-"):
        raise HTTPException(status_code=415, detail="Uploaded file is not a PDF")
    parse_id = uuid4()
    temporary_path: Path | None = None
    try:
        with NamedTemporaryFile(prefix="cas-", suffix=".pdf", delete=False) as tmp:
            tmp.write(payload)
            temporary_path = Path(tmp.name)
        result = service.parse_file(
            temporary_path,
            parse_id=parse_id,
            password=password,
            firm_id=firm_id,
            client_id=client_id,
        )
        repository.save(result)
        # Persist to PostgreSQL — failures are logged but never block the response
        try:
            db_repo = StatementRepository(db)
            await db_repo.save_statement(result, source_filename=file.filename)
        except Exception as db_exc:
            import structlog
            structlog.get_logger().warning("db_save_failed", error=str(db_exc))
        return result
    except CASParserError as exc:
        detail = ErrorDetail(
            code=exc.code,
            message=str(exc) or "Unable to parse document",
            retryable=exc.retryable,
            hint=exc.hint,  # type: ignore[attr-defined]
        )
        if isinstance(exc, LowQualityExtractionError):
            detail.chars_extracted = exc.chars_extracted
            detail.pages_extracted = exc.pages
        raise HTTPException(status_code=400, detail=detail.model_dump(exclude_none=True)) from exc
    finally:
        if temporary_path:
            temporary_path.unlink(missing_ok=True)


@router.post(
    "/inspect",
    response_model=InspectResponse,
    summary="Inspect PDF extraction quality without parsing",
    tags=["diagnostics"],
)
async def inspect_pdf(
    file: UploadFile = File(...),
    password: str | None = Form(default=None),
    service: ParseService = Depends(get_parse_service),
) -> InspectResponse:
    """Upload a PDF to see how much text was extracted — useful for debugging LOW_QUALITY_EXTRACTION."""
    settings = get_settings()
    payload = await file.read(settings.max_upload_size_bytes + 1)
    if not payload.startswith(b"%PDF-"):
        raise HTTPException(status_code=415, detail="Not a PDF file")
    temporary_path: Path | None = None
    try:
        with NamedTemporaryFile(prefix="inspect-", suffix=".pdf", delete=False) as tmp:
            tmp.write(payload)
            temporary_path = Path(tmp.name)
        try:
            doc = service.extractor.extract(temporary_path, password=password)
        except Exception:
            doc = None
        if doc is None:
            return InspectResponse(
                pages=0, chars_extracted=0, quality_sufficient=False,
                scanned_page_count=0, extraction_method="failed",
                ocr_enabled=settings.ocr_enabled, sample_text="",
            )
        quality = service.extractor.quality(doc)
        sample = doc.text[:500].replace("\n", " ").strip()
        return InspectResponse(
            pages=quality.page_count,
            chars_extracted=quality.character_count,
            quality_sufficient=quality.sufficient,
            scanned_page_count=quality.scanned_page_count,
            extraction_method=doc.extraction_method,
            ocr_enabled=settings.ocr_enabled,
            sample_text=sample,
        )
    finally:
        if temporary_path:
            temporary_path.unlink(missing_ok=True)


@router.get("/parses/{parse_id}", response_model=Statement)
def get_parse(parse_id: UUID, repository: InMemoryParseRepository = Depends(get_repository)) -> Statement:
    result = repository.get(parse_id)
    if result is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Parse result not found")
    return result
