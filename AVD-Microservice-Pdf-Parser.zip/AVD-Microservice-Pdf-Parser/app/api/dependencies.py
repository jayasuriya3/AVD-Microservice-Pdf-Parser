from functools import lru_cache

from app.application.parse_service import ParseService
from app.classifier.cams_rules import CAMSRules
from app.classifier.cdsl_rules import CDSLRules
from app.classifier.kfintech_rules import KFintechRules
from app.classifier.nsdl_rules import NSDLRules
from app.classifier.provider_classifier import ProviderClassifier
from app.core.config import Settings, get_settings
from app.extractors.base import DocumentExtractor
from app.extractors.multi_engine_ocr import MultiEngineOCRExtractor
from app.extractors.ocr_extractor import TesseractOCRExtractor
from app.extractors.pdfplumber_extractor import PdfPlumberExtractor
from app.extractors.pymupdf_extractor import PyMuPDFExtractor
from app.extractors.rapidocr_extractor import RapidOCRExtractor
from app.extractors.strategy import ExtractionStrategy
from app.parsers.cams import CAMSParser
from app.parsers.cdsl import CDSLParser
from app.parsers.kfintech import KFintechParser
from app.parsers.nsdl import NSDLParser
from app.parsers.registry import ParserRegistry
from app.repositories.in_memory import InMemoryParseRepository


def _build_ocr_extractor(settings: Settings) -> DocumentExtractor | None:
    if not settings.ocr_enabled:
        return None
    backend = settings.ocr_backend.lower()
    if backend == "tesseract":
        return TesseractOCRExtractor(
            dpi=settings.ocr_dpi,
            min_confidence=settings.ocr_tesseract_min_confidence,
            lang=settings.ocr_lang,
        )
    if backend == "rapidocr":
        return RapidOCRExtractor(
            dpi=settings.ocr_dpi,
            min_confidence=settings.ocr_rapidocr_min_confidence,
        )
    return MultiEngineOCRExtractor([
        TesseractOCRExtractor(
            dpi=settings.ocr_dpi,
            min_confidence=settings.ocr_tesseract_min_confidence,
            lang=settings.ocr_lang,
        ),
        RapidOCRExtractor(
            dpi=settings.ocr_dpi,
            min_confidence=settings.ocr_rapidocr_min_confidence,
        ),
    ])


@lru_cache
def get_parse_service() -> ParseService:
    settings = get_settings()
    strategy = ExtractionStrategy(
        primary=PdfPlumberExtractor(),
        fallback=PyMuPDFExtractor(),
        settings=settings,
        ocr_extractor=_build_ocr_extractor(settings),
    )
    return ParseService(
        strategy,
        ProviderClassifier([NSDLRules(), CDSLRules(), CAMSRules(), KFintechRules()]),
        ParserRegistry([NSDLParser(), CDSLParser(), CAMSParser(), KFintechParser()]),
    )


@lru_cache
def get_repository() -> InMemoryParseRepository:
    return InMemoryParseRepository()


def _build_ocr_extractor(settings: Settings) -> DocumentExtractor | None:
    """Construct the OCR extractor based on the configured backend."""
    if not settings.ocr_enabled:
        return None
    backend = settings.ocr_backend.lower()
    if backend == "tesseract":
        return TesseractOCRExtractor(
            dpi=settings.ocr_dpi,
            min_confidence=settings.ocr_tesseract_min_confidence,
            lang=settings.ocr_lang,
        )
    if backend == "rapidocr":
        return RapidOCRExtractor(
            dpi=settings.ocr_dpi,
            min_confidence=settings.ocr_rapidocr_min_confidence,
        )
    # Default: multi_engine — tries both, picks the best page result
    return MultiEngineOCRExtractor([
        TesseractOCRExtractor(
            dpi=settings.ocr_dpi,
            min_confidence=settings.ocr_tesseract_min_confidence,
            lang=settings.ocr_lang,
        ),
        RapidOCRExtractor(
            dpi=settings.ocr_dpi,
            min_confidence=settings.ocr_rapidocr_min_confidence,
        ),
    ])
