from uuid import UUID

from pydantic import BaseModel

from app.models.enums import ParseStatus
from app.models.statement import Statement


class ErrorDetail(BaseModel):
    code: str
    message: str
    retryable: bool = False
    hint: str | None = None
    chars_extracted: int | None = None
    pages_extracted: int | None = None


class ErrorResponse(BaseModel):
    error: ErrorDetail


class ParseResponse(Statement):
    parse_id: UUID
    status: ParseStatus


class InspectResponse(BaseModel):
    pages: int
    chars_extracted: int
    quality_sufficient: bool
    scanned_page_count: int
    extraction_method: str
    ocr_enabled: bool
    sample_text: str
