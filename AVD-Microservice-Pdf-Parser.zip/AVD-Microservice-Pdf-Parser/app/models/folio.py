from pydantic import BaseModel, Field

from app.models.scheme import Scheme


class Folio(BaseModel):
    folio_number: str
    amc_name: str | None = None
    kyc_status: str | None = None
    nominee: str | None = None
    schemes: list[Scheme] = Field(default_factory=list)
