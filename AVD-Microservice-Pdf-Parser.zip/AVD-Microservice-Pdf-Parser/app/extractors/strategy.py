"""Extraction strategy: hybrid text + selective per-page OCR pipeline."""
from __future__ import annotations

from pathlib import Path

import structlog

from app.core.config import Settings
from app.core.exceptions import LowQualityExtractionError
from app.extractors.base import DocumentExtractor
from app.extractors.image_preprocessor import estimate_scan_likelihood
from app.extractors.models import ExtractionQuality, PageQuality
from app.models.document import ExtractedDocument, ExtractedPage

log = structlog.get_logger()


class ExtractionStrategy:
    """
    Four-stage extraction pipeline:
      1. pdfplumber  — primary, best for native-text CAS PDFs
      2. Hybrid OCR  — per-page selective: OCR only scanned/blank pages
      3. PyMuPDF     — fallback for encrypted / complex PDFs
      4. Full OCR    — last resort when all text extraction fails
    """

    def __init__(
        self,
        primary: DocumentExtractor,
        fallback: DocumentExtractor,
        settings: Settings,
        ocr_extractor: DocumentExtractor | None = None,
    ) -> None:
        self.primary = primary
        self.fallback = fallback
        self.settings = settings
        self.ocr_extractor = ocr_extractor

    # ── Public API ──────────────────────────────────────────────────

    def extract(self, path: Path, password: str | None = None) -> ExtractedDocument:
        for extractor in (self.primary, self.fallback):
            doc = self._try_and_enhance(extractor, path, password)
            if doc is not None:
                return doc
        return self._full_ocr_or_raise(path, password)

    def _try_and_enhance(self, extractor: DocumentExtractor, path: Path, password: str | None) -> ExtractedDocument | None:
        doc = self._try_extract(extractor, path, password)
        if doc is None:
            return None
        doc = self._maybe_enhance(path, doc, password)
        quality = self.quality(doc)
        # Accept low-quality docs when the flag is set (useful for borderline PDFs)
        if not quality.sufficient and not self.settings.accept_low_quality:
            return None
        log.info("extraction_complete", method=doc.extraction_method, pages=len(doc.pages), chars=quality.character_count)
        return doc

    def _maybe_enhance(self, path: Path, doc: ExtractedDocument, password: str | None) -> ExtractedDocument:
        if self.settings.ocr_enabled and self.ocr_extractor is not None:
            return self._hybrid_enhance(path, doc, password)
        return doc

    def _full_ocr_or_raise(self, path: Path, password: str | None) -> ExtractedDocument:
        best: ExtractedDocument | None = None
        if self.settings.ocr_enabled and self.ocr_extractor is not None:
            best = self._try_extract(self.ocr_extractor, path, password)
            if best is not None and self.quality(best).sufficient:
                log.info("extraction_complete", method="full_ocr")
                return best
        chars = best.character_count if best else 0
        pages = len(best.pages) if best else 0
        raise LowQualityExtractionError(chars_extracted=chars, pages=pages)

    def quality(self, document: ExtractedDocument) -> ExtractionQuality:
        reasons: list[str] = []
        if not document.pages:
            reasons.append("no_pages")
        if document.character_count < self.settings.min_extracted_characters:
            reasons.append("insufficient_text")
        scanned = sum(1 for p in document.pages if not self._page_quality(p).sufficient)
        return ExtractionQuality(
            sufficient=not reasons,
            character_count=document.character_count,
            page_count=len(document.pages),
            scanned_page_count=scanned,
            reasons=reasons,
        )

    # ── Hybrid per-page OCR ──────────────────────────────────────────

    def _hybrid_enhance(self, path: Path, primary: ExtractedDocument, password: str | None) -> ExtractedDocument:
        """OCR only low-quality pages; keep native text pages untouched."""
        if self.ocr_extractor is None:
            return primary

        scanned_pages = [p for p in primary.pages if not self._page_quality(p).sufficient]
        if not scanned_pages:
            return primary

        log.info("hybrid_ocr_triggered", scanned_page_count=len(scanned_pages))
        ocr_doc = self._try_extract(self.ocr_extractor, path, password)
        if ocr_doc is None:
            return primary

        ocr_by_number = {p.page_number: p for p in ocr_doc.pages}
        enhanced: list[ExtractedPage] = []
        for page in primary.pages:
            if self._page_quality(page).sufficient:
                enhanced.append(page)
            else:
                ocr_page = ocr_by_number.get(page.page_number)
                if ocr_page and len(ocr_page.raw_text.strip()) > len(page.raw_text.strip()):
                    log.debug("page_replaced_by_ocr", page_number=page.page_number)
                    enhanced.append(ocr_page)
                else:
                    enhanced.append(page)

        return ExtractedDocument(
            pages=enhanced,
            metadata={**primary.metadata, "enhancement": "hybrid_ocr"},
            extraction_method="hybrid_pdfplumber_ocr",
        )

    # ── Helpers ──────────────────────────────────────────────────────

    def _try_extract(self, extractor: DocumentExtractor, path: Path, password: str | None) -> ExtractedDocument | None:
        try:
            return extractor.extract(path, password=password)
        except Exception as exc:
            log.warning("extractor_failed", extractor=type(extractor).__name__, error=str(exc))
            return None

    def _page_quality(self, page: ExtractedPage) -> PageQuality:
        char_count = len(page.raw_text.strip())
        return PageQuality(
            page_number=page.page_number,
            sufficient=char_count >= self.settings.min_chars_per_page,
            char_count=char_count,
        )
