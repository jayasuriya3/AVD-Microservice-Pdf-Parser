"""RapidOCR ONNX extractor – no C++ or Tesseract system dependency.

RapidOCR uses ONNX Runtime for inference, making it portable across
platforms without a compiled Tesseract binary.
"""
from __future__ import annotations

from decimal import Decimal
from pathlib import Path
from typing import Any

import pymupdf as fitz

from app.core.exceptions import EncryptedPDFError
from app.extractors.base import DocumentExtractor
from app.extractors.image_preprocessor import pdf_page_to_pil, preprocess_for_ocr
from app.models.document import ExtractedDocument, ExtractedPage, ExtractedWord


class RapidOCRExtractor(DocumentExtractor):
    """
    RapidOCR ONNX-based OCR:
    - No system-level Tesseract installation required
    - ONNX Runtime inference (CPU, portable)
    - Returns word-level bounding boxes from text-line detections
    - Confidence filtering at 0.4 threshold
    """

    def __init__(self, dpi: int = 300, min_confidence: float = 0.4) -> None:
        self.dpi = dpi
        self.min_confidence = min_confidence
        self._engine: object | None = None

    def _get_engine(self) -> Any:
        if self._engine is None:
            try:
                from rapidocr_onnxruntime import RapidOCR

                self._engine = RapidOCR()
            except ImportError as exc:
                raise RuntimeError("rapidocr-onnxruntime not installed. Run: pip install 'advisordesk-cas-parser[ocr]'") from exc
        return self._engine

    def extract(self, path: Path, password: str | None = None) -> ExtractedDocument:
        import numpy as np

        engine = self._get_engine()
        pages: list[ExtractedPage] = []

        with fitz.open(path) as pdf:
            if password and not pdf.authenticate(password):
                raise EncryptedPDFError
            for page_number, fitz_page in enumerate(pdf, start=1):
                pil_image = pdf_page_to_pil(fitz_page, dpi=self.dpi)
                processed = preprocess_for_ocr(pil_image)
                img_array = np.array(processed)
                result, _ = engine(img_array)
                pages.append(self._build_page(result or [], page_number))

        return ExtractedDocument(
            pages=pages,
            metadata={"ocr_engine": "rapidocr", "dpi": str(self.dpi)},
            extraction_method="ocr_rapidocr",
        )

    def _build_page(self, result: list[list], page_number: int) -> ExtractedPage:
        words: list[ExtractedWord] = []
        text_lines: list[str] = []

        for item in result:
            # RapidOCR returns: [bbox_quad, text, confidence]
            bbox, text, confidence = item[0], str(item[1]).strip(), float(item[2])
            if not text or confidence < self.min_confidence:
                continue
            # bbox is 4 corner points [[x1,y1],[x2,y2],[x3,y3],[x4,y4]]
            xs = [float(pt[0]) for pt in bbox]
            ys = [float(pt[1]) for pt in bbox]
            words.append(ExtractedWord(
                text=text,
                x0=Decimal(str(min(xs))), top=Decimal(str(min(ys))),
                x1=Decimal(str(max(xs))), bottom=Decimal(str(max(ys))),
            ))
            text_lines.append(text)

        return ExtractedPage(
            page_number=page_number,
            raw_text="\n".join(text_lines),
            words=words,
        )
