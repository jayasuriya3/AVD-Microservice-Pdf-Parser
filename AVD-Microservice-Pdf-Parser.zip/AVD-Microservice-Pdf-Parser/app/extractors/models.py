from pydantic import BaseModel, Field


class PageQuality(BaseModel):
    page_number: int
    sufficient: bool
    char_count: int


class ExtractionQuality(BaseModel):
    sufficient: bool
    character_count: int
    page_count: int
    scanned_page_count: int = 0
    reasons: list[str] = Field(default_factory=list)
