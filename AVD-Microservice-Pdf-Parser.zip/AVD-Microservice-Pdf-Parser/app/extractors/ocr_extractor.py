"""Enhanced Tesseract OCR extractor with preprocessing and word-level coordinates."""
from __future__ import annotations

from decimal import Decimal
from pathlib import Path

import pymupdf as fitz

from app.core.exceptions import EncryptedPDFError
from app.extractors.base import DocumentExtractor
from app.extractors.image_preprocessor import pdf_page_to_pil, preprocess_for_ocr
from app.models.document import ExtractedDocument, ExtractedPage, ExtractedWord


class TesseractOCRExtractor(DocumentExtractor):
    """
    Tesseract OCR with:
    - 300 DPI rendering (vs 144 DPI default)
    - OpenCV/Pillow image preprocessing (deskew, denoise, adaptive threshold)
    - Word-level bounding boxes for position-aware CAS parsing
    - Confidence filtering (discards low-confidence words)
    """

    def __init__(self, dpi: int = 300, min_confidence: int = 40, lang: str = "eng") -> None:
        self.dpi = dpi
        self.min_confidence = min_confidence
        self.lang = lang

    def extract(self, path: Path, password: str | None = None) -> ExtractedDocument:
        try:
            import pytesseract
        except ImportError as exc:
            raise RuntimeError("pytesseract not installed. Run: pip install 'advisordesk-cas-parser[ocr]'") from exc

        pages: list[ExtractedPage] = []
        with fitz.open(path) as pdf:
            if password and not pdf.authenticate(password):
                raise EncryptedPDFError
            for page_number, fitz_page in enumerate(pdf, start=1):
                pil_image = pdf_page_to_pil(fitz_page, dpi=self.dpi)
                processed = preprocess_for_ocr(pil_image)
                pages.append(self._ocr_page(pytesseract, processed, page_number))

        return ExtractedDocument(
            pages=pages,
            metadata={"ocr_engine": "tesseract", "dpi": str(self.dpi), "lang": self.lang},
            extraction_method="ocr_tesseract",
        )

    def _ocr_page(self, pytesseract: object, image: object, page_number: int) -> ExtractedPage:
        # image_to_data gives per-word confidence + bounding boxes
        data = pytesseract.image_to_data(  # type: ignore[attr-defined]
            image, lang=self.lang, output_type=pytesseract.Output.DICT,  # type: ignore[attr-defined]
        )
        words: list[ExtractedWord] = []
        n = len(data["text"])
        for i in range(n):
            token = str(data["text"][i]).strip()
            conf = int(data["conf"][i])
            if not token or conf < self.min_confidence:
                continue
            x = Decimal(str(data["left"][i]))
            y = Decimal(str(data["top"][i]))
            w = Decimal(str(data["width"][i]))
            h = Decimal(str(data["height"][i]))
            words.append(ExtractedWord(text=token, x0=x, top=y, x1=x + w, bottom=y + h))

        raw_text: str = pytesseract.image_to_string(image, lang=self.lang)  # type: ignore[attr-defined]
        return ExtractedPage(page_number=page_number, raw_text=raw_text.strip(), words=words)
