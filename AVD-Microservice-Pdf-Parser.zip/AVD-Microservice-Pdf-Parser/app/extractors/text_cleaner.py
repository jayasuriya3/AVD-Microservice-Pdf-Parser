"""Text cleaning utilities to remove non-English characters."""
import re


def clean_text_keep_english_only(text: str) -> str:
    """
    Remove non-English characters and scripts (Hindi, etc.).
    Keeps: ASCII letters, numbers, common punctuation, spaces, newlines.
    Removes: Devanagari, Arabic, and other non-Latin scripts.
    """
    if not text:
        return text
    
    # Pattern: keep only ASCII printable + newlines/tabs
    # This removes Devanagari (Hindi), Arabic, CJK, and other scripts
    cleaned = re.sub(r'[^\x00-\x7F\n\t\r]', '', text)
    
    # Clean up excessive whitespace but preserve line structure
    cleaned = re.sub(r'[ \t]+', ' ', cleaned)  # Multiple spaces → single space
    cleaned = re.sub(r'\n\s*\n', '\n', cleaned)  # Multiple blank lines → single newline
    
    return cleaned.strip()
