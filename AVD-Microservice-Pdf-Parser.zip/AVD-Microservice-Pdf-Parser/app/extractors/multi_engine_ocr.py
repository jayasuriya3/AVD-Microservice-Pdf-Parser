"""Multi-engine OCR ensemble: runs available engines and picks the best page result.

Engine priority (quality): RapidOCR ≥ Tesseract (both open-source, no API cost).
The ensemble picks the page with the highest character count as a quality proxy.
"""
from __future__ import annotations

from pathlib import Path

import structlog

from app.extractors.base import DocumentExtractor
from app.models.document import ExtractedDocument, ExtractedPage

log = structlog.get_logger()


class MultiEngineOCRExtractor(DocumentExtractor):
    """
    Runs multiple OCR engines and selects the best page-level result.

    Resilient: if an engine is not installed or fails, it is skipped
    without crashing the pipeline.
    """

    def __init__(self, engines: list[DocumentExtractor]) -> None:
        if not engines:
            raise ValueError("MultiEngineOCRExtractor requires at least one engine")
        self._engines = engines

    def extract(self, path: Path, password: str | None = None) -> ExtractedDocument:
        candidates: list[ExtractedDocument] = []

        for engine in self._engines:
            try:
                doc = engine.extract(path, password=password)
                candidates.append(doc)
                log.debug("ocr_engine_succeeded", engine=type(engine).__name__, pages=len(doc.pages))
            except Exception as exc:
                log.warning("ocr_engine_skipped", engine=type(engine).__name__, reason=str(exc))

        if not candidates:
            raise RuntimeError(
                "All OCR engines failed. Install at least one: "
                "pip install 'advisordesk-cas-parser[ocr]'"
            )

        if len(candidates) == 1:
            return candidates[0]

        return self._merge(candidates)

    def _merge(self, docs: list[ExtractedDocument]) -> ExtractedDocument:
        """Merge multiple engine results, picking the best page per position."""
        max_pages = max(len(d.pages) for d in docs)
        merged: list[ExtractedPage] = []

        for idx in range(max_pages):
            page_candidates = [d.pages[idx] for d in docs if idx < len(d.pages)]
            merged.append(self._best_page(page_candidates))

        combined_methods = "+".join(
            d.extraction_method for d in docs if d.extraction_method
        )
        return ExtractedDocument(
            pages=merged,
            metadata={"ocr_engine": "multi_engine", "engines": combined_methods},
            extraction_method=f"ocr_ensemble({combined_methods})",
        )

    @staticmethod
    def _best_page(candidates: list[ExtractedPage]) -> ExtractedPage:
        """Highest character count is the quality heuristic."""
        return max(candidates, key=lambda p: len(p.raw_text.strip()))
