"""
OpenAI GPT fallback extractor.
Called when parse confidence is below the configured threshold.
Uses requests directly to avoid aiohttp/SSL issues on Windows.
"""
import json
import re
from decimal import Decimal, InvalidOperation

import requests
import structlog

log = structlog.get_logger()

_SYSTEM_PROMPT = """You are a financial document parser for Indian CAS (Consolidated Account Statement) PDFs.
Extract structured data from the provided text and return ONLY valid JSON with this exact schema:

{
  "investor_name": "string or null",
  "pan": "string or null",
  "statement_date": "DD-MM-YYYY or null",
  "provider": "CDSL|NSDL|CAMS|KFINTECH",
  "folios": [
    {
      "folio_number": "string",
      "scheme_name": "string",
      "isin": "string or null",
      "units": number_or_null,
      "nav": number_or_null,
      "current_value": number_or_null,
      "invested_value": number_or_null
    }
  ],
  "demat_holdings": [
    {
      "isin": "12-char ISIN",
      "security_name": "string",
      "quantity": number,
      "market_price": number_or_null,
      "current_value": number_or_null
    }
  ]
}

Rules:
- Extract ALL folios and holdings present in the text
- ISINs are 12 characters starting with IN
- Numbers must be plain numbers (no commas, no ₹ symbol)
- Return ONLY the JSON object, no explanation
"""


def call_openai(text: str, api_key: str, model: str) -> dict:
    """Call OpenAI chat completion and return parsed JSON."""
    # Truncate text to fit within token limits (~12k chars ≈ 3k tokens)
    truncated = text[:12000]

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": _SYSTEM_PROMPT},
            {"role": "user", "content": f"Extract data from this CAS statement:\n\n{truncated}"},
        ],
        "temperature": 0,
        "response_format": {"type": "json_object"},
    }

    resp = requests.post(
        "https://api.openai.com/v1/chat/completions",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        json=payload,
        timeout=60,
    )
    resp.raise_for_status()
    content = resp.json()["choices"][0]["message"]["content"]
    return json.loads(content)


def _dec(val) -> Decimal | None:
    if val is None:
        return None
    try:
        return Decimal(str(val))
    except InvalidOperation:
        return None


def merge_openai_into_statement(statement, openai_data: dict) -> None:
    """
    Merge OpenAI extraction results into an existing Statement in-place.
    Only fills in fields that are None/empty in the original parse.
    """
    from app.models.folio import Folio
    from app.models.scheme import Scheme

    investor = statement.investor
    if not investor.name and openai_data.get("investor_name"):
        investor.name = openai_data["investor_name"]
    if not investor.pan_masked and openai_data.get("pan"):
        investor.pan_masked = openai_data["pan"]

    if not statement.statement.statement_date and openai_data.get("statement_date"):
        from app.parsers.shared.date_utils import parse_cas_date
        statement.statement.statement_date = parse_cas_date(openai_data["statement_date"])

    # Fill in missing folio/scheme data
    existing_folios = {
        f["folio_number"] if isinstance(f, dict) else f.folio_number
        for f in statement.folios
    }
    for f in openai_data.get("folios", []):
        folio_num = f.get("folio_number", "")
        if folio_num in existing_folios:
            # Update existing scheme values if missing
            for existing in statement.folios:
                d = existing if isinstance(existing, dict) else existing.__dict__
                if d.get("folio_number") == folio_num:
                    for scheme in d.get("schemes", []):
                        s = scheme if isinstance(scheme, dict) else scheme.__dict__
                        if s.get("units") is None:
                            s["units"] = _dec(f.get("units"))
                        if s.get("nav") is None:
                            s["nav"] = _dec(f.get("nav"))
                        if s.get("current_value") is None:
                            s["current_value"] = _dec(f.get("current_value"))
                        if s.get("invested_value") is None:
                            s["invested_value"] = _dec(f.get("invested_value"))
        else:
            # Add new folio not found by regex parser
            scheme = Scheme(
                scheme_name_raw=f.get("scheme_name", ""),
                isin=f.get("isin"),
                units=_dec(f.get("units")),
                nav=_dec(f.get("nav")),
                current_value=_dec(f.get("current_value")),
                invested_value=_dec(f.get("invested_value")),
                confidence=Decimal("0.8"),
            )
            folio_obj = Folio(folio_number=folio_num, schemes=[scheme])
            statement.folios.append(folio_obj.model_dump())
            existing_folios.add(folio_num)

    # Fill in missing demat holdings
    if openai_data.get("demat_holdings") and statement.demat_accounts:
        existing_isins = {
            h.isin
            for acct in statement.demat_accounts
            for h in acct.holdings
        }
        from app.models.demat import DematHolding
        target = next(
            (a for a in statement.demat_accounts if a.holdings),
            statement.demat_accounts[0],
        )
        for h in openai_data.get("demat_holdings", []):
            isin = h.get("isin", "")
            if isin and isin not in existing_isins:
                target.holdings.append(DematHolding(
                    isin=isin,
                    security_name=h.get("security_name"),
                    quantity=_dec(h.get("quantity")) or Decimal("0"),
                    market_price=_dec(h.get("market_price")),
                    current_value=_dec(h.get("current_value")),
                ))
                existing_isins.add(isin)
