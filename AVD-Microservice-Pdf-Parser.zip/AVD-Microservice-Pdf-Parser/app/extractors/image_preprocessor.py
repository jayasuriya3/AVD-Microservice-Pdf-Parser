"""Open-source image preprocessing pipeline for scanned CAS PDF pages.

Preprocessing chain: PDF page → high-DPI render → grayscale → denoise →
adaptive threshold → deskew. Falls back to Pillow-only if OpenCV is absent.
"""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import numpy as np
    from PIL import Image as PILImage


def pdf_page_to_pil(fitz_page: object, dpi: int = 300) -> "PILImage.Image":
    """Render a PyMuPDF page to a PIL Image at the given DPI."""
    import pymupdf as fitz  # optional dep: PyMuPDF
    from PIL import Image

    matrix = fitz.Matrix(dpi / 72, dpi / 72)
    pixmap = fitz_page.get_pixmap(matrix=matrix, alpha=False)  # type: ignore[attr-defined]
    return Image.frombytes("RGB", [pixmap.width, pixmap.height], pixmap.samples)


def preprocess_for_ocr(image: "PILImage.Image") -> "PILImage.Image":
    """Apply the full preprocessing chain, degrading gracefully without OpenCV."""
    try:
        return _preprocess_opencv(image)
    except ImportError:
        return _preprocess_pillow(image)


# ──────────────────────────────────────────────────────────────────────
# OpenCV pipeline (preferred)
# ──────────────────────────────────────────────────────────────────────

def _preprocess_opencv(image: "PILImage.Image") -> "PILImage.Image":
    import cv2
    import numpy as np
    from PIL import Image

    img = np.array(image.convert("RGB"))
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)

    # Fast non-local means denoising – handles scanner noise well
    denoised = cv2.fastNlMeansDenoising(gray, h=10, templateWindowSize=7, searchWindowSize=21)

    # Adaptive Gaussian threshold: handles uneven lighting across page
    binary = cv2.adaptiveThreshold(
        denoised, 255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        blockSize=15, C=8,
    )

    corrected = _deskew(binary)
    return Image.fromarray(corrected)


def _deskew(img: "np.ndarray") -> "np.ndarray":
    """Correct page rotation using minimum-area bounding rect of dark pixels."""
    import cv2
    import numpy as np

    dark_coords = np.argwhere(img < 128)  # shape (N,2): [[row,col], ...]
    if len(dark_coords) < 100:
        return img

    angle = cv2.minAreaRect(dark_coords)[-1]
    # Normalise to [-45, 45]
    if angle < -45:
        angle = 90.0 + angle
    elif angle > 45:
        angle = angle - 90.0

    if abs(angle) < 0.3:  # ignore sub-0.3° skew – not worth the warp cost
        return img

    h, w = img.shape
    M = cv2.getRotationMatrix2D((w // 2, h // 2), angle, 1.0)
    return cv2.warpAffine(img, M, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)


# ──────────────────────────────────────────────────────────────────────
# Pillow-only fallback pipeline
# ──────────────────────────────────────────────────────────────────────

def _preprocess_pillow(image: "PILImage.Image") -> "PILImage.Image":
    from PIL import ImageEnhance, ImageFilter

    img = image.convert("L")
    img = img.filter(ImageFilter.MedianFilter(size=3))
    img = ImageEnhance.Contrast(img).enhance(2.0)
    return img


def estimate_scan_likelihood(raw_text: str, char_count_threshold: int = 50) -> float:
    """Return 0.0–1.0 probability that a PDF page is a scan (not native text).

    Higher score → more likely scanned → OCR should be applied.
    """
    stripped = raw_text.strip()
    if not stripped:
        return 1.0
    if len(stripped) >= char_count_threshold:
        return 0.0
    return 1.0 - len(stripped) / char_count_threshold
