"""KFintech investor section parser."""
from __future__ import annotations

from app.parsers.kfintech import patterns as P

_SKIP_TOKENS = frozenset({
    "kfintech", "kfin", "karvy", "consolidated", "account", "statement",
    "page", "date", "email", "mobile", "address", "arn", "generated",
    "period", "for", "the", "kyc", "pan", "nominee", "folio", "isin",
    "registrar", "transfer", "summary", "investments", "investment",
    "registered", "total", "grand",
})


def parse_investor_name(text: str, lines: list[str], period_line_idx: int) -> str | None:
    import re
    m = P.NAME_LABEL_RE.search(text)
    if m:
        candidate = m.group(1).strip()
        if _is_valid_name(candidate):
            return candidate.title()
    name_re = re.compile(r"^[A-Z][A-Za-z .]{4,60}$")
    for line in lines[period_line_idx : period_line_idx + 50]:
        line = line.strip()
        lower = line.lower()
        if not line or any(tok in lower for tok in _SKIP_TOKENS):
            continue
        if P.EMAIL_RE.search(line) or P.PAN_RE.search(line) or P.MOBILE_RE.search(line):
            continue
        if P.SCHEME_SKIP_RE.search(line):
            continue
        if name_re.match(line) and _is_valid_name(line):
            return line.title()
    return None


def _is_valid_name(name: str) -> bool:
    words = name.split()
    if len(words) < 2:
        return False
    lower = name.lower()
    return not any(tok in lower for tok in _SKIP_TOKENS)


def parse_pan(text: str) -> str | None:
    m = P.PAN_RE.search(text)
    return m.group(1).upper() if m else None
