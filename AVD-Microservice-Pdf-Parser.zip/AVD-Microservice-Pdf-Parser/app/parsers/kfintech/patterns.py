"""KFintech CAS PDF regex patterns."""
from __future__ import annotations

import re

PERIOD_RE = re.compile(
    r"(\d{1,2}[\-/ ][A-Za-z]{3}[\-/ ]\d{4}|\d{1,2}/\d{1,2}/\d{4})"
    r"\s+[Tt][Oo]\s+"
    r"(\d{1,2}[\-/ ][A-Za-z]{3}[\-/ ]\d{4}|\d{1,2}/\d{1,2}/\d{4})",
)
NAME_LABEL_RE = re.compile(r"(?:^|\n)\s*Name\s*[:\-]\s*([A-Z][A-Za-z ,.]{3,80})", re.MULTILINE)
PAN_RE = re.compile(r"\bPAN\s*[:\-]?\s*([A-Z]{5}[0-9]{4}[A-Z])\b", re.IGNORECASE)
EMAIL_RE = re.compile(r"([A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,})")
MOBILE_RE = re.compile(
    r"(?:Mobile|Mob|Ph(?:one)?)\s*(?:No\.?)?\s*[:\-]?\s*(?:\+?91[\s\-]?)?([6-9]\d{9})", re.IGNORECASE
)
AMC_RE = re.compile(
    r"^([A-Z][A-Z0-9\s&.(),\-]{5,79}?(?:MUTUAL\s+FUND|ASSET\s+MANAGEMENT))\s*$", re.MULTILINE
)
FOLIO_RE = re.compile(
    r"Folio\s*(?:No\.?)?\s*[:\-]\s*([\w\-\/]+(?:\s*/\s*[A-Z0-9]+)?)", re.IGNORECASE
)
KYC_RE = re.compile(r"KYC\s*(?:of\s+Investor[/s]*)?\s*[:\-]?\s*(KYC\s+\w+|\w+)", re.IGNORECASE)
NOMINEE_RE = re.compile(r"Nominee\s*[:\-]?\s*(\w+(?:\s+\w+)?)", re.IGNORECASE)
ISIN_LINE_RE = re.compile(r"ISIN\s*[:\-]?\s*([A-Z]{2}[A-Z0-9]{10})\b", re.IGNORECASE)
FACE_VALUE_RE = re.compile(
    r"Face\s+Value\s*[:\-]?\s*(?:Rs\.?\s*|₹\s*)?(\d+(?:\.\d+)?)", re.IGNORECASE
)
SCHEME_SKIP_RE = re.compile(
    r"KYC|Mobile\s*No|Nominee|Folio\s*No|ISIN|Face\s+Value|Registrar|Transfer\s+Agent"
    r"|Summary|Consolidated|Account\s+Statement|Page\s+\d",
    re.IGNORECASE,
)
_NUM = r"(?:[\d,]+\.\d+|\([\d,]+\.\d+\)|[-\*]{1,3})"
TXN_FULL_RE = re.compile(
    rf"^\s*(\d{{1,2}}[-/][A-Za-z]{{3}}[-/]\d{{4}})\s+"
    rf"(.+?)\s+"
    rf"({_NUM})\s+({_NUM})\s+({_NUM})\s+({_NUM})\s*$",
    re.MULTILINE,
)
VALUATION_HEADER_RE = re.compile(
    r"(?:Portfolio\s+Valuation|Valuation\s+(?:as\s+)?on|Market\s+Value|NAV\s+Details)",
    re.IGNORECASE,
)
VALUATION_DATA_RE = re.compile(r"([\d,]+\.\d{3,4})[\s,]+([\d,]+\.\d{3,4})[\s,]+([\d,]+\.\d{2,4})")
INLINE_VAL_RE = re.compile(
    r"Units?\s*[:\-]?\s*([\d,]+\.\d+).*NAV\s*[:\-]?\s*([\d,]+\.\d+).*"
    r"(?:Value|Val)\s*[:\-]?\s*([\d,]+\.\d+)",
    re.IGNORECASE,
)
INVESTED_RE = re.compile(
    r"(?:Invested|Cost)\s+(?:Value|Amount|Val)\s*[:\-]?\s*(?:Rs\.?\s*|₹\s*)?([\d,]+\.\d{2})",
    re.IGNORECASE,
)
GAIN_LOSS_RE = re.compile(
    r"(?:Gain|Net\s+Gain|Gain\s*/\s*Loss|P&L)\s*[:\-]?\s*(?:Rs\.?\s*|₹\s*)?(\(?[\d,]+\.\d{2}\)?)",
    re.IGNORECASE,
)
_TYPE_MAP = [
    ("DIVIDEND_REINVESTMENT", re.compile(r"\b(?:IDCW|Dividend)\s*Reinvest", re.IGNORECASE)),
    ("DIVIDEND",             re.compile(r"\b(?:Dividend|IDCW)\b", re.IGNORECASE)),
    ("SWITCH_IN",            re.compile(r"\bSwitch(?:\s*|-)(In|Pur)\b|\bSTP\s*In\b", re.IGNORECASE)),
    ("SWITCH_OUT",           re.compile(r"\bSwitch(?:\s*|-)(Out|Red)\b|\bSTP\s*Out\b", re.IGNORECASE)),
    ("REDEMPTION",           re.compile(r"\b(?:Redemption|SWP|Systematic\s+Withdrawal|Redeem)\b", re.IGNORECASE)),
    ("SIP",                  re.compile(r"\bSIP\b|Systematic\s+Inv(?:estment)?\s+Plan", re.IGNORECASE)),
    ("PURCHASE",             re.compile(r"\b(?:Purchase|Lumpsum|Subscription|NFO|Initial|New)\b", re.IGNORECASE)),
]


def classify_txn_type(description: str) -> str:
    for tx_type, pattern in _TYPE_MAP:
        if pattern.search(description):
            return tx_type
    return "UNKNOWN"
