"""KFintech scheme name + ISIN extractor."""
from __future__ import annotations

from app.parsers.kfintech import patterns as P
from app.parsers.shared.money_utils import parse_indian_decimal


def extract_scheme_name(folio_text: str, isin_match_start: int) -> str | None:
    line_start = folio_text.rfind("\n", 0, isin_match_start) + 1
    before_isin = folio_text[line_start:isin_match_start].strip()
    if before_isin and len(before_isin) > 8 and not P.SCHEME_SKIP_RE.search(before_isin):
        return before_isin
    preceding = folio_text[:line_start]
    for line in reversed(preceding.splitlines()):
        line = line.strip()
        if not line or len(line) <= 8 or P.SCHEME_SKIP_RE.search(line):
            continue
        return line
    return None


def extract_isin(line: str) -> str | None:
    m = P.ISIN_LINE_RE.search(line)
    return m.group(1).upper() if m else None


def extract_face_value(text: str) -> object:
    m = P.FACE_VALUE_RE.search(text)
    return parse_indian_decimal(m.group(1)) if m else None
