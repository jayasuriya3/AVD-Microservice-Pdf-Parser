"""KFintech statement metadata parser."""
from __future__ import annotations

from datetime import date

from app.parsers.kfintech import patterns as P
from app.parsers.shared.date_utils import parse_cas_date


def parse_period(text: str) -> tuple[date | None, date | None]:
    m = P.PERIOD_RE.search(text)
    if not m:
        return None, None
    return parse_cas_date(m.group(1)), parse_cas_date(m.group(2))
