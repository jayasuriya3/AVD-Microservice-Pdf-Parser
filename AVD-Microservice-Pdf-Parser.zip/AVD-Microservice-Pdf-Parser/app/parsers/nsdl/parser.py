"""NSDL e-CAS parser.

NSDL CAS has distinct quirks:
  - Page headers use doubled characters: "NNaattiioonnaall SSeeccuurriittiieess"
  - Holdings table format: {ISIN} {NAME} {qty} 0.000 0.000 {price} {value}
  - Investor identified by "NSDL ID: {id}" then name on next line
  - PAN is masked in the document (e.g., CGXXXXXX2H)
  - Both NSDL and linked CDSL accounts listed
"""
import re
from decimal import Decimal, InvalidOperation

from app.models.demat import DematAccount, DematHolding
from app.models.document import ExtractedDocument
from app.models.enums import Provider
from app.models.folio import Folio
from app.parsers.base import BaseCASParser, ParserMatch, RawCASResult
from app.services.security_master import canonical_security_name, trading_symbol


class NSDLParser(BaseCASParser):
    provider = Provider.NSDL

    def can_parse(self, document: ExtractedDocument) -> ParserMatch:
        text = document.text.lower()
        matches = "nsdl id:" in text and "nsdl" in text
        return ParserMatch(provider=self.provider, confidence=1 if matches else 0)

    def parse(self, document: ExtractedDocument) -> RawCASResult:
        text = document.text
        warnings: list[str] = []

        investor_name = self._investor_name(text)
        pan_masked = self._pan_masked(text)
        statement_date = self._statement_date(text)
        demat_accounts = self._demat_accounts(text)

        if not demat_accounts:
            warnings.append("no_demat_accounts_found")

        return RawCASResult(
            provider=self.provider,
            investor_name=investor_name,
            investor_pan=pan_masked,
            statement_date=statement_date,
            folios=[],
            demat_accounts=demat_accounts,
            warnings=warnings,
        )

    # ── Private extraction methods ────────────────────────────────────────────

    @staticmethod
    def _investor_name(text: str) -> str | None:
        # "NSDL ID: 133515585\nSHANMUGAM\n"
        m = re.search(r"NSDL\s+ID\s*:\s*\S+\s*\n([A-Z][A-Z ]{2,60})", text)
        return m.group(1).strip() if m else None

    @staticmethod
    def _pan_masked(text: str) -> str | None:
        # PAN is masked: "CGXXXXXX2H" — extract as-is
        m = re.search(r"\bPAN\s*[:\(]?\s*([A-Z]{2}[X0-9]{6}[0-9][A-Z])\b", text, re.IGNORECASE)
        return m.group(1).upper() if m else None

    @staticmethod
    def _statement_date(text: str) -> str | None:
        # "Statement for the period from 01-Jul-2026 to 31-Jul-2026"
        m = re.search(r"period\s+from\s+\S+\s+to\s+(\d{2}-[A-Za-z]{3}-\d{4})", text, re.IGNORECASE)
        return m.group(1) if m else None

    @classmethod
    def _demat_accounts(cls, text: str) -> list[DematAccount]:
        """Extract all NSDL/CDSL demat accounts and their holdings from the text."""
        accounts: list[DematAccount] = []

        # Find each account block: "DP ID:{dp_id} Client ID:{client_id}"
        # NSDL: "DP ID:IN303382 Client ID:10293524"
        # CDSL: "DP ID:12081601 Client ID:37881486"
        for m in re.finditer(
            r"(?P<dp_name>[A-Z][A-Z &.(),\-]{5,79}?)\s*\n"
            r"(?P<dep>NSDL|CDSL)\s+Demat\s+Account.*?\n"
            r"DP\s+ID\s*:\s*(?P<dp_id>[A-Z0-9]+)\s+Client\s+ID\s*:\s*(?P<client_id>[A-Z0-9]+)",
            text,
            flags=re.IGNORECASE,
        ):
            accounts.append(DematAccount(
                depository=m.group("dep").upper(),
                dp_name=m.group("dp_name").strip(),
                dp_id=m.group("dp_id"),
                client_id=m.group("client_id"),
            ))

        # Extract holdings from the holdings table section
        holdings = cls._parse_holdings(text)

        # Attach holdings to the first account that has securities (usually CDSL/Zerodha for NSDL CAS)
        if holdings:
            # Prefer CDSL account if present (linked account with actual holdings)
            target = next(
                (a for a in accounts if a.depository == "CDSL"),
                accounts[0] if accounts else None,
            )
            if target is None:
                target = DematAccount(depository="NSDL", dp_name="NSDL Consolidated Account")
                accounts.append(target)
            target.holdings = holdings

        return accounts

    @staticmethod
    def _parse_holdings(text: str) -> list[DematHolding]:
        """
        NSDL holding table row format (3 lines per security):
          INE092T01019 IDFC FIRST BANK LIMITED # 3.000 0.000 0.000 84.70 254.10
          EQUITY SHARES 3.000 0.000 0.000
          0.000 0.000 0.000

        The ISIN, security name (partial), qty, price, and value are on line 1.
        Name may continue on line 2 before the second set of numbers.
        """
        # Single-line holding pattern — captures ISIN, then price and value as last two numbers
        row_re = re.compile(
            r"^(?P<isin>IN[A-Z][A-Z0-9]{9})\s+"
            r"(?P<name_part>[A-Z][^0-9\n]{0,80}?)\s+"
            r"(?P<qty>[\d,]+\.\d{3})\s+"   # current balance
            r"[\d.]+\s+[\d.]+\s+"           # safekeep + pledged (usually 0.000)
            r"(?P<price>[\d,]+\.\d+)\s+"
            r"(?P<value>[\d,]+\.\d+)",
            re.MULTILINE,
        )

        holdings: list[DematHolding] = []
        seen: set[str] = set()

        for m in row_re.finditer(text):
            isin = m.group("isin")
            if isin in seen:
                continue
            seen.add(isin)

            name_raw = re.sub(r"\s+", " ", m.group("name_part")).strip()
            # Strip trailing "#" or special chars
            name_raw = re.sub(r"[#\-]+$", "", name_raw).strip()

            try:
                qty = Decimal(m.group("qty").replace(",", ""))
                price = Decimal(m.group("price").replace(",", ""))
                value = Decimal(m.group("value").replace(",", ""))
            except InvalidOperation:
                continue

            holdings.append(DematHolding(
                isin=isin,
                security_name=canonical_security_name(isin, name_raw),
                trading_symbol=trading_symbol(isin),
                quantity=qty,
                market_price=price,
                current_value=value,
            ))

        return holdings
