from __future__ import annotations

import re
from datetime import date

_MONTH_MAP: dict[str, int] = {
    "jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
    "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12,
}

_DMY_ALPHA_RE = re.compile(r"^(\d{1,2})[-/]([A-Za-z]{3})[-/](\d{4})$")
_DMY_NUM_RE = re.compile(r"^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$")
_DATE_SCAN_RE = re.compile(r"\d{1,2}[-/][A-Za-z]{3}[-/]\d{4}|\d{1,2}[-/]\d{1,2}[-/]\d{4}")


def parse_cas_date(value: str) -> date | None:
    """Parse DD-Mon-YYYY, DD/MM/YYYY, DD-MM-YYYY, and ISO formats."""
    value = value.strip()
    m = _DMY_ALPHA_RE.match(value)
    if m:
        month = _MONTH_MAP.get(m.group(2).lower())
        if month:
            try:
                return date(int(m.group(3)), month, int(m.group(1)))
            except ValueError:
                pass
    m = _DMY_NUM_RE.match(value)
    if m:
        try:
            return date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
        except ValueError:
            pass
    try:
        return date.fromisoformat(value)
    except ValueError:
        return None


def parse_iso_date(value: str) -> date | None:
    try:
        return date.fromisoformat(value)
    except ValueError:
        return None


def extract_first_date(text: str) -> date | None:
    """Extract the first recognisable date from arbitrary text."""
    for m in _DATE_SCAN_RE.finditer(text):
        d = parse_cas_date(m.group(0))
        if d:
            return d
    return None
