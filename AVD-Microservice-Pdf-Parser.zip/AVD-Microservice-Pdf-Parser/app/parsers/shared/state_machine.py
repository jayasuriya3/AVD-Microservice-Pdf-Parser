from __future__ import annotations

from enum import StrEnum


class ParseState(StrEnum):
    START = "START"
    INVESTOR = "INVESTOR"
    FOLIO = "FOLIO"
    SCHEME = "SCHEME"
    TRANSACTIONS = "TRANSACTIONS"
    VALUATION = "VALUATION"
    END = "END"


class CASStateMachine:
    def __init__(self) -> None:
        self.state = ParseState.START
        self.current_folio: str | None = None
        self.current_scheme: str | None = None
        self.current_amc: str | None = None

    def transition(self, new_state: ParseState) -> None:
        self.state = new_state

    def enter_folio(self, folio_number: str, amc: str | None = None) -> None:
        self.current_folio = folio_number
        self.current_amc = amc
        self.transition(ParseState.FOLIO)

    def enter_scheme(self, scheme_name: str) -> None:
        self.current_scheme = scheme_name
        self.transition(ParseState.SCHEME)

    def enter_transactions(self) -> None:
        self.transition(ParseState.TRANSACTIONS)

    def enter_valuation(self) -> None:
        self.transition(ParseState.VALUATION)
