from __future__ import annotations

import re
from decimal import Decimal, InvalidOperation

_CLEAN_RE = re.compile(r"[₹\s]")
_NULL_RE = re.compile(r"^[-*]+$")  # CAMS uses "---" or "***" for N/A


def parse_decimal(value: str) -> Decimal | None:
    """Parse a decimal from plain or Indian-formatted number strings."""
    return parse_indian_decimal(value)


def parse_indian_decimal(value: str) -> Decimal | None:
    """Handle Indian number format (1,23,456.78) and parenthesised negatives."""
    cleaned = _CLEAN_RE.sub("", value.strip())
    if not cleaned or _NULL_RE.match(cleaned):
        return None
    negative = cleaned.startswith("(") and cleaned.endswith(")")
    if negative:
        cleaned = "-" + cleaned[1:-1]
    cleaned = cleaned.replace(",", "")
    try:
        return Decimal(cleaned)
    except InvalidOperation:
        return None


def is_null_value(value: str) -> bool:
    """Return True for CAMS/KFintech N/A markers like '---' or '***'."""
    return bool(_NULL_RE.match(value.strip()))
