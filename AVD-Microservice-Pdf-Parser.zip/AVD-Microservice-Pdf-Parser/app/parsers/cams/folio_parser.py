"""CAMS folio section splitter and parser."""
from __future__ import annotations

from app.models.folio import Folio
from app.models.scheme import Scheme
from app.parsers.cams import patterns as P
from app.parsers.cams.scheme_parser import extract_face_value, extract_scheme_name
from app.parsers.cams.transaction_parser import parse_transactions
from app.parsers.cams.valuation_parser import parse_valuation


def parse_folios(text: str, warnings: list[str]) -> list[Folio]:
    folio_spans = [(m.group(1).strip(), m.start()) for m in P.FOLIO_RE.finditer(text)]
    if not folio_spans:
        warnings.append("no_folio_headers_found")
        return []
    folios: list[Folio] = []
    for idx, (folio_number, start) in enumerate(folio_spans):
        end = folio_spans[idx + 1][1] if idx + 1 < len(folio_spans) else len(text)
        folio_text = text[start:end]
        amc_name = _find_amc_before(text, start)
        kyc_status, nominee = _parse_kyc(folio_text)
        schemes = _parse_schemes(folio_text, warnings)
        folios.append(Folio(
            folio_number=folio_number,
            amc_name=amc_name,
            kyc_status=kyc_status,
            nominee=nominee,
            schemes=schemes,
        ))
    return folios


def _find_amc_before(text: str, folio_start: int) -> str | None:
    last_amc = None
    for m in P.AMC_RE.finditer(text[:folio_start]):
        last_amc = m.group(1).strip()
    return last_amc


def _parse_kyc(folio_text: str) -> tuple[str | None, str | None]:
    header = folio_text[:500]
    kyc_m = P.KYC_RE.search(header)
    nom_m = P.NOMINEE_RE.search(header)
    return (kyc_m.group(1).strip() if kyc_m else None,
            nom_m.group(1).strip() if nom_m else None)


def _parse_schemes(folio_text: str, warnings: list[str]) -> list[Scheme]:
    isin_matches = list(P.ISIN_LINE_RE.finditer(folio_text))
    if not isin_matches:
        return []
    schemes: list[Scheme] = []
    for i, isin_m in enumerate(isin_matches):
        isin = isin_m.group(1).upper()
        scheme_end = isin_matches[i + 1].start() if i + 1 < len(isin_matches) else len(folio_text)
        scheme_text = folio_text[isin_m.start() : scheme_end]
        scheme_name = extract_scheme_name(folio_text, isin_m.start()) or f"Unknown ({isin})"
        face_value = extract_face_value(scheme_text[:300])
        transactions = parse_transactions(scheme_text)
        units, nav, current_value, invested_value, gain_loss = parse_valuation(scheme_text)
        schemes.append(Scheme(
            scheme_name_raw=scheme_name,
            isin=isin,
            face_value=face_value,
            units=units,
            nav=nav,
            current_value=current_value,
            invested_value=invested_value,
            gain_loss=gain_loss,
            transactions=transactions,
        ))
    return schemes
