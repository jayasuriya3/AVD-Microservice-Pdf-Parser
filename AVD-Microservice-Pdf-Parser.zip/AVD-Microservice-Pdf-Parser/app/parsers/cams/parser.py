from __future__ import annotations

import re

import structlog

from app.models.document import ExtractedDocument
from app.models.enums import Provider
from app.parsers.base import BaseCASParser, ParserMatch, RawCASResult
from app.parsers.cams import patterns as P
from app.parsers.cams.folio_parser import parse_folios
from app.parsers.cams.investor_parser import parse_email, parse_investor_name, parse_mobile, parse_pan
from app.parsers.cams.statement_parser import parse_period

log = structlog.get_logger()


class CAMSParser(BaseCASParser):
    provider = Provider.CAMS

    def can_parse(self, document: ExtractedDocument) -> ParserMatch:
        text = document.text.lower()
        score, signals = 0.0, []
        if "cams" in text or "computer age management services" in text:
            score += 0.5
            signals.append("provider_name_found")
        if "consolidated account statement" in text:
            score += 0.3
            signals.append("known_statement_header")
        if re.search(r"registrar\s+and\s+transfer\s+agent", text, re.IGNORECASE):
            score += 0.2
            signals.append("rta_phrase_found")
        return ParserMatch(provider=Provider.CAMS, confidence=min(score, 1.0), signals=signals)

    def parse(self, document: ExtractedDocument) -> RawCASResult:
        text = document.text
        warnings: list[str] = []

        period_from, period_to = parse_period(text)
        lines = [ln.strip() for ln in text.splitlines()]
        period_line_idx = next(
            (i for i, ln in enumerate(lines) if P.PERIOD_RE.search(ln)), 0
        )
        investor_name = parse_investor_name(text, lines, period_line_idx)
        pan = parse_pan(text)
        email = parse_email(text)
        mobile = parse_mobile(text)
        folios = parse_folios(text, warnings)

        if not folios:
            warnings.append("no_folios_extracted")

        log.info("cams_parse_complete", investor=investor_name, folios=len(folios), period_to=str(period_to))
        return RawCASResult(
            provider=Provider.CAMS,
            investor_name=investor_name,
            investor_pan=pan,
            investor_email=email,
            investor_mobile=mobile,
            statement_date=str(period_to) if period_to else None,
            folios=folios,
            warnings=warnings,
        )
