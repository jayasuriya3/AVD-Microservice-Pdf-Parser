"""CAMS valuation section parser: units, NAV, current value, invested value, gain/loss."""
from __future__ import annotations

from decimal import Decimal

from app.parsers.cams import patterns as P
from app.parsers.shared.money_utils import parse_indian_decimal


def parse_valuation(
    scheme_text: str,
) -> tuple[Decimal | None, Decimal | None, Decimal | None, Decimal | None, Decimal | None]:
    """Return (units, nav, current_value, invested_value, gain_loss)."""
    # Try inline format first: "Units: X NAV: Y Value: Z" on one line
    inline = P.INLINE_VAL_RE.search(scheme_text)
    if inline:
        units = parse_indian_decimal(inline.group(1))
        nav   = parse_indian_decimal(inline.group(2))
        value = parse_indian_decimal(inline.group(3))
        inv_m = P.INVESTED_RE.search(scheme_text)
        gl_m  = P.GAIN_LOSS_RE.search(scheme_text)
        return units, nav, value, \
               parse_indian_decimal(inv_m.group(1)) if inv_m else None, \
               parse_indian_decimal(gl_m.group(1))  if gl_m  else None

    # Standard tabular format after the valuation header
    header = P.VALUATION_HEADER_RE.search(scheme_text)
    if not header:
        return None, None, None, None, None

    section = scheme_text[header.start() : header.start() + 800]
    data = P.VALUATION_DATA_RE.search(section)
    if not data:
        return None, None, None, None, None

    units = parse_indian_decimal(data.group(1))
    nav   = parse_indian_decimal(data.group(2))
    value = parse_indian_decimal(data.group(3))
    inv_m = P.INVESTED_RE.search(section)
    gl_m  = P.GAIN_LOSS_RE.search(section)
    return units, nav, value, \
           parse_indian_decimal(inv_m.group(1)) if inv_m else None, \
           parse_indian_decimal(gl_m.group(1))  if gl_m  else None
