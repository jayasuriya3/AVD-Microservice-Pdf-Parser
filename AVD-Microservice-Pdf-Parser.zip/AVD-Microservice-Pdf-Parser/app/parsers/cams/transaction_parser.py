"""CAMS transaction line parser."""
from __future__ import annotations

from app.models.enums import TransactionType
from app.models.transaction import Transaction
from app.parsers.cams import patterns as P
from app.parsers.shared.date_utils import parse_cas_date
from app.parsers.shared.money_utils import is_null_value, parse_indian_decimal


def parse_transactions(scheme_text: str) -> list[Transaction]:
    transactions: list[Transaction] = []
    for m in P.TXN_FULL_RE.finditer(scheme_text):
        description = m.group(2).strip()
        if "opening balance" in description.lower():
            continue
        tx_date = parse_cas_date(m.group(1))
        amount = None if is_null_value(m.group(3)) else parse_indian_decimal(m.group(3))
        units  = None if is_null_value(m.group(4)) else parse_indian_decimal(m.group(4))
        nav    = None if is_null_value(m.group(5)) else parse_indian_decimal(m.group(5))
        tx_type_str = P.classify_txn_type(description)
        try:
            tx_type = TransactionType(tx_type_str)
        except ValueError:
            tx_type = TransactionType.UNKNOWN
        transactions.append(Transaction(date=tx_date, type=tx_type, amount=amount, units=units, nav=nav))
    return transactions
