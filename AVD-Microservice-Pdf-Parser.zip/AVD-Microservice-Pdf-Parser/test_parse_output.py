import time, requests, json

time.sleep(3)

pdf_path = r'C:\Users\320259325\Downloads\JUL2026_AA28544033_TXN (1).pdf'
with open(pdf_path, 'rb') as f:
    resp = requests.post('http://localhost:8000/v1/parse',
                         files={'file': ('cas.pdf', f, 'application/pdf')},
                         data={'password': 'CEUPJ9812H'})

data = resp.json()

print('Provider:', data['provider']['name'], data['provider']['confidence'])
print('Investor:', data['investor']['name'])
print('PAN:', data['investor']['pan_masked'])
print('Statement date:', data['statement']['statement_date'])
print()
print('Folios:', len(data['folios']))
for fol in data['folios']:
    folio_no = fol['folio_number']
    print(f'  Folio: {folio_no}')
    for s in fol['schemes']:
        name = s['scheme_name_raw']
        isin = s['isin']
        units = s['units']
        nav = s['nav']
        val = s['current_value']
        inv = s['invested_value']
        print(f'    {name}')
        print(f'    ISIN:{isin}  Units:{units}  NAV:{nav}  Value:{val}  Invested:{inv}')
print()
print('Demat accounts:', len(data['demat_accounts']))
for acct in data['demat_accounts']:
    dp_name = acct['dp_name']
    dp_id = acct['dp_id']
    cid = acct['client_id']
    h_count = len(acct['holdings'])
    print(f'  {dp_name} (DP:{dp_id}/Client:{cid}) - {h_count} holdings')
