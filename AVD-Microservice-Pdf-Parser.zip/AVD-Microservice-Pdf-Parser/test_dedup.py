"""Verify duplicate prevention — upload same PDF three times, expect 1 row."""
import requests

PDF = r"C:\Users\320259325\Downloads\JUL2026_AA28544033_TXN (1).pdf"
PARAMS = {"password": "CEUPJ9812H", "firm_id": "WEALTH_MGR_001", "client_id": "CL_JAYASURIYA_001"}


def upload() -> str:
    with open(PDF, "rb") as f:
        r = requests.post("http://localhost:8000/v1/parse",
                          files={"file": ("cas.pdf", f, "application/pdf")},
                          data=PARAMS)
    d = r.json()
    return d.get("parse_id", "ERROR")


if __name__ == "__main__":
    import subprocess
    PSQL = [r"C:\Program Files\PostgreSQL\18\bin\psql.exe", "-U", "postgres", "-d", "cas_parser"]

    def query(sql: str) -> str:
        return subprocess.check_output(PSQL + ["-c", sql], text=True).strip()

    print("Upload 1:", upload())
    print("Upload 2 (same PDF):", upload())
    print("Upload 3 (same PDF):", upload())
    print()
    print(query("SELECT COUNT(*) AS statements FROM cas_statements WHERE provider='CDSL';"))
    print(query("SELECT COUNT(*) AS holdings FROM demat_holdings;"))
    print(query("SELECT COUNT(*) AS folios FROM mf_folios;"))
    print(query("SELECT COUNT(*) AS schemes FROM mf_schemes;"))
    print()
    print("Expected: 1 statement, 44 holdings (not 132), 2 folios (not 6), 2 schemes (not 6)")
