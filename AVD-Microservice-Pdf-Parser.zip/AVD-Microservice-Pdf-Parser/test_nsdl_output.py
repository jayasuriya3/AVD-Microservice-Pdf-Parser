import time, requests, json

time.sleep(3)

pdf_path = r'C:\Users\320259325\Downloads\NSDLe-CAS_133515585_JUL_2026.PDF'
with open(pdf_path, 'rb') as f:
    resp = requests.post('http://localhost:8000/v1/parse',
                         files={'file': ('nsdl.pdf', f, 'application/pdf')},
                         data={'password': 'CGBPS1452H'})

data = resp.json()

print('Provider:', data['provider']['name'], data['provider']['confidence'])
print('Signals:', data['provider']['signals'])
print('Investor:', data['investor']['name'])
print('PAN:', data['investor']['pan_masked'])
print('Statement date:', data['statement']['statement_date'])
print()
print('Folios:', len(data['folios']))
print('Demat accounts:', len(data['demat_accounts']))
for acct in data['demat_accounts']:
    dp = acct['dp_name']
    dep = acct['depository']
    h_count = len(acct['holdings'])
    total_val = sum(float(h['current_value']) for h in acct['holdings'])
    print(f'  [{dep}] {dp} - {h_count} holdings, value: {total_val:,.2f}')
    for h in acct['holdings'][:5]:
        print(f'    {h["isin"]} {h["security_name"][:35]:<35} qty={h["quantity"]}  val={h["current_value"]}')
    if h_count > 5:
        print(f'    ... +{h_count-5} more')
