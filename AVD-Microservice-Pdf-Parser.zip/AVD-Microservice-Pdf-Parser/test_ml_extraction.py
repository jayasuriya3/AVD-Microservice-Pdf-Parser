"""
Quick test of ML-based extraction.
Run: python test_ml_extraction.py
"""
from app.ml_models import FinancialNERExtractor

# Initialize extractor (downloads model on first run ~400MB)
print("Initializing FinancialNERExtractor...")
extractor = FinancialNERExtractor()

# Sample CAS document text
sample_text = """
CONSOLIDATED ACCOUNT STATEMENT FOR SECURITIES HELD IN DEMAT
01-07-2026 to 31-07-2026

CAS ID: 123456789

Jayasuriya S
PAN: CEUPJ9812H
Email: suriyashan98@gmail.com

Folio Number: 41418985/45
Scheme Name: ICICI Prudential Equity & Debt Fund - Growth
ISIN: INF109K01480
Units: 11.177
NAV: 408.33
Current Value: 4563.90

Folio Number: 499475281106/0
Scheme Name: NIPPON INDIA GOLD SAVINGS FUND - GROWTH PLAN
ISIN: INF204K01KN0
Units: 52.218
NAV: 53.8626
Current Value: 2812.60

Demat Account 1:
DP Name: ZERODHA BROKING LIMITED
DP ID: 12081600
Client ID: 57802693

Holdings:
ISIN: INE885A01032, Security: Amara Raja Energy & Mobility Limited, Quantity: 2.000
ISIN: INE208A01029, Security: Ashok Leyland Limited, Quantity: 90.000
"""

# Extract all entities
print("\nExtracting entities...")
result = extractor.extract_all(sample_text)

print("\n=== EXTRACTION RESULTS ===")
print(f"Investor Name: {result['investor_name']}")
print(f"PAN: {result['pan']}")
print(f"Statement Date: {result['statement_date']}")
print(f"ISINs Found: {result['isins']}")
print(f"Numeric Values: {result['numeric_values']}")
print(f"Folio-Scheme Mapping: {result['folio_schemes']}")

print("\n✅ ML extraction complete!")
