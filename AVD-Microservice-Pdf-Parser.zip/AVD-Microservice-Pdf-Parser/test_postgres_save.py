"""Test both CDSL and NSDL PDFs via API and verify data in PostgreSQL."""
import asyncio
import requests
import json

PGBIN = r"C:\Program Files\PostgreSQL\18\bin\psql.exe"


def parse_pdf(pdf_path: str, password: str, firm_id: str, client_id: str, label: str) -> dict:
    with open(pdf_path, "rb") as f:
        resp = requests.post(
            "http://localhost:8000/v1/parse",
            files={"file": (f"{label}.pdf", f, "application/pdf")},
            data={"password": password, "firm_id": firm_id, "client_id": client_id},
        )
    data = resp.json()
    print(f"\n{'='*60}")
    print(f"[{label}] Status: {resp.status_code}")
    print(f"  Provider:       {data.get('provider', {}).get('name')} (confidence={data.get('provider', {}).get('confidence')})")
    print(f"  firm_id:        {data.get('firm_id')}")
    print(f"  client_id:      {data.get('client_id')}")
    print(f"  Investor:       {data.get('investor', {}).get('name')}")
    print(f"  PAN:            {data.get('investor', {}).get('pan_masked')}")
    print(f"  Statement date: {data.get('statement', {}).get('statement_date')}")
    print(f"  Folios:         {len(data.get('folios', []))}")
    total_holdings = sum(len(a.get('holdings', [])) for a in data.get('demat_accounts', []))
    print(f"  Holdings:       {total_holdings}")
    print(f"  parse_id:       {data.get('parse_id')}")
    return data


if __name__ == "__main__":
    cdsl = parse_pdf(
        r"C:\Users\320259325\Downloads\JUL2026_AA28544033_TXN (1).pdf",
        password="CEUPJ9812H",
        firm_id="WEALTH_MGR_001",
        client_id="CL_JAYASURIYA_001",
        label="CDSL",
    )

    nsdl = parse_pdf(
        r"C:\Users\320259325\Downloads\NSDLe-CAS_133515585_JUL_2026.PDF",
        password="CGBPS1452H",
        firm_id="WEALTH_MGR_001",
        client_id="CL_SHANMUGAM_001",
        label="NSDL",
    )

    print("\n" + "="*60)
    print("Both parsed. Now checking PostgreSQL...")
    print("="*60)
    import subprocess
    result = subprocess.run(
        [PGBIN, "-U", "postgres", "-d", "cas_parser", "-c",
         r"\echo '-- FIRMS --' ; SELECT firm_code FROM firms ; "
         r"\echo '-- CLIENTS --' ; SELECT external_ref, full_name, pan FROM clients ; "
         r"\echo '-- STATEMENTS --' ; SELECT provider, investor_name, investor_pan, statement_date, parse_status FROM cas_statements ORDER BY parsed_at ; "
         r"\echo '-- DEMAT ACCOUNTS --' ; SELECT depository, dp_name, dp_id FROM demat_accounts ; "
         r"\echo '-- HOLDINGS COUNT --' ; SELECT COUNT(*) as total_holdings FROM demat_holdings ; "
         r"\echo '-- MF FOLIOS --' ; SELECT folio_number FROM mf_folios ; "
         r"\echo '-- MF SCHEMES --' ; SELECT scheme_name_raw, isin, units, nav, current_value, invested_value FROM mf_schemes ; "
        ],
        capture_output=True, text=True
    )
    print(result.stdout)
    if result.returncode != 0:
        print("Error:", result.stderr[:500])
