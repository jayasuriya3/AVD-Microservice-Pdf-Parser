import json
from pathlib import Path

# Validate dataset structure
data = json.loads(Path('training_data/training_dataset.json').read_text())

print('📊 DATASET VALIDATION')
print('='*70)

required_fields = ['text', 'investor_name', 'pan', 'statement_date', 'isins', 'folios', 'provider']

for i, sample in enumerate(data, 1):
    missing = [f for f in required_fields if f not in sample]
    status = 'OK' if not missing else 'FAIL'
    name = sample['investor_name']
    print(f'{status:4} Sample {i}: {name}')

print('\n' + '='*70)
print('\n📈 STATISTICS:')
print(f'  Total samples: {len(data)}')
providers = set(s["provider"] for s in data)
print(f'  Providers: {providers}')
print(f'  Avg folios/sample: {sum(len(s["folios"]) for s in data) / len(data):.1f}')
print(f'  Avg ISINs/sample: {sum(len(s["isins"]) for s in data) / len(data):.1f}')
print(f'  Avg text length: {sum(len(s["text"]) for s in data) / len(data):.0f} chars')
print('\n✅ Dataset validated and ready!')
