"""
Extract text from real PDFs and create training dataset.
Usage: python extract_pdfs_for_training.py --pdf-dir ./pdfs --output ./training_data
"""
import argparse
import json
from pathlib import Path

from app.extractors.strategy import ExtractionStrategy
from app.extractors.pdfplumber_extractor import PdfPlumberExtractor
from app.extractors.pymupdf_extractor import PyMuPDFExtractor
from app.core.config import Settings
from app.ml_models.dataset_generator import add_pdf_to_dataset


def extract_and_prepare_training(
    pdf_dir: str,
    output_dir: str = "./training_data",
    annotation_file: str = None
) -> None:
    """
    Extract PDFs and prepare training data.
    
    Args:
        pdf_dir: Directory containing PDF files
        output_dir: Directory to save training JSON
        annotation_file: Optional JSON file with manual annotations
            Format: {"sample1.pdf": {"investor_name": "...", "pan": "...", ...}}
    """
    pdf_path = Path(pdf_dir)
    if not pdf_path.exists():
        print(f"❌ PDF directory not found: {pdf_dir}")
        return
    
    # Load manual annotations if provided
    annotations = {}
    if annotation_file and Path(annotation_file).exists():
        with open(annotation_file, "r") as f:
            annotations = json.load(f)
        print(f"📝 Loaded annotations for {len(annotations)} PDFs")
    
    # Initialize extraction strategy
    settings = Settings()
    strategy = ExtractionStrategy(
        primary=PdfPlumberExtractor(),
        fallback=PyMuPDFExtractor(),
        settings=settings,
        ocr_extractor=None
    )
    
    # Process each PDF
    pdf_files = list(pdf_path.glob("*.pdf"))
    print(f"\n📁 Found {len(pdf_files)} PDF files")
    
    for i, pdf_file in enumerate(pdf_files, 1):
        print(f"\n[{i}/{len(pdf_files)}] Processing: {pdf_file.name}")
        
        try:
            # Extract text
            doc = strategy.extract(pdf_file)
            extracted_text = doc.text
            print(f"  ✅ Extracted {len(extracted_text)} characters")
            
            # Get metadata
            metadata = annotations.get(pdf_file.name, {})
            
            # If no annotations, prompt user to provide them
            if not metadata:
                print(f"\n  ⚠️  No annotations for {pdf_file.name}")
                print("  Please provide manually:")
                print(f"    investor_name: ", end="")
                investor_name = input() or "Unknown"
                print(f"    pan: ", end="")
                pan = input() or None
                print(f"    statement_date (DD-MM-YYYY): ", end="")
                statement_date = input() or None
                print(f"    provider (CDSL/CAMS/KFINTECH): ", end="")
                provider = input() or "UNKNOWN"
                
                metadata = {
                    "investor_name": investor_name,
                    "pan": pan,
                    "statement_date": statement_date,
                    "provider": provider,
                    "email": None,
                    "mobile": None,
                    "isins": [],
                    "folios": [],
                    "securities": [],
                }
            
            # Add to dataset
            add_pdf_to_dataset(extracted_text, metadata, output_dir)
            
        except Exception as e:
            print(f"  ❌ Error processing {pdf_file.name}: {e}")
    
    print(f"\n✅ Training dataset saved to {output_dir}/")
    print(f"📊 Ready for model training!")


def create_annotation_template(pdf_dir: str, output_file: str = "annotations_template.json") -> None:
    """
    Create annotation template for PDFs.
    User fills in the template and passes to extract_and_prepare_training.
    """
    pdf_path = Path(pdf_dir)
    pdf_files = list(pdf_path.glob("*.pdf"))
    
    template = {}
    for pdf_file in pdf_files:
        template[pdf_file.name] = {
            "investor_name": "TODO: Name from CAS ID line",
            "pan": "TODO: 10-char PAN code",
            "email": "TODO: Email if present",
            "mobile": "TODO: Mobile if present",
            "statement_date": "TODO: DD-MM-YYYY",
            "provider": "TODO: CDSL|CAMS|KFINTECH",
            "isins": ["TODO: List ISINs found"],
            "folios": ["TODO: List Folio numbers"],
            "securities": [
                {
                    "isin": "TODO",
                    "name": "TODO: Security name",
                    "qty": "TODO: Quantity",
                    "price": "TODO: Price/NAV"
                }
            ],
        }
    
    with open(output_file, "w") as f:
        json.dump(template, f, indent=2)
    
    print(f"✅ Created annotation template: {output_file}")
    print(f"   Edit and fill in the values, then run:")
    print(f"   python extract_pdfs_for_training.py --pdf-dir {pdf_dir} --annotations {output_file}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Extract PDFs for ML training dataset")
    parser.add_argument("--pdf-dir", default="./pdfs", help="Directory with PDF files")
    parser.add_argument("--output", default="./training_data", help="Output directory for training data")
    parser.add_argument("--annotations", help="JSON file with manual annotations")
    parser.add_argument("--template", action="store_true", help="Create annotation template only")
    
    args = parser.parse_args()
    
    if args.template:
        create_annotation_template(args.pdf_dir, "annotations_template.json")
    else:
        extract_and_prepare_training(args.pdf_dir, args.output, args.annotations)
